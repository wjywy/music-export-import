// This file runs before content.js. It never changes article text nodes.
(() => {
  const excluded = 'script,style,noscript,input,textarea,select,button,shiju-clipper,[hidden],[contenteditable]:not([contenteditable="false"])';
  function indexText() {
    const spans = [];
    const parts = [];
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT, { acceptNode: node => node.parentElement?.closest(excluded) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    let length = 0;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!node.data.length) continue;
      spans.push({ node, start: length, end: length + node.data.length });
      parts.push(node.data); length += node.data.length;
      if (length > 4_000_000 || spans.length > 100000) throw new Error('页面文字过多，暂时无法标记。仍可使用剪藏。');
    }
    return { spans, text: parts.join('') };
  }
  function anchorRange(range, index = indexText()) {
    let start; let end;
    for (const span of index.spans) {
      if (!range.intersectsNode(span.node)) continue;
      const from = range.startContainer === span.node ? range.startOffset : 0;
      const to = range.endContainer === span.node ? range.endOffset : span.node.length;
      if (from === to) continue;
      start ??= span.start + from; end = span.start + to;
    }
    if (start === undefined || end === undefined || index.text.slice(start, end) !== range.toString()) throw new Error('这段内容无法准确定位，请选择正文文字，或先使用剪藏。');
    return { start, end, exact: index.text.slice(start, end), prefix: index.text.slice(Math.max(0, start - 64), start), suffix: index.text.slice(end, end + 64) };
  }
  function rangeAt(index, start, end) {
    const first = index.spans.find(span => span.start <= start && span.end > start);
    const last = index.spans.find(span => span.start < end && span.end >= end);
    if (!first || !last) return null;
    const range = document.createRange();
    range.setStart(first.node, start - first.start); range.setEnd(last.node, end - last.start);
    return range;
  }
  globalThis.__shijuAnchors = { indexText, anchorRange, rangeAt, resolveAnchor: globalThis.__shijuResolveAnchor };
})();
