import { imageNodes } from './lib/article-document.js';
import { prepareImages, startImages, retryImage, imageRetention, recoverImages, cleanImages, freezeImageSnapshot } from './lib/image-capture.js';
import { stageOriginal, acceptOriginal, rejectOriginal, updateOriginal, deleteOriginal, originalWorkspace, originalState } from './lib/originals.js';
import { normalizeClip, normalizeSettings, isConnected, publicSettings, workbenchSettings, destinationKey, destinationLabel, parseFeishuUrl, parseRepo, fingerprint } from './lib/core.js';
import { saveYuque, saveFeishu, testConnection } from './lib/api.js';
import { createYuqueImages } from './lib/yuque-images.js';
import { getState, putJob, clearJobs, recoverInterruptedJobs, writeAnnotations } from './lib/store.js';
import { normalizeAnnotation, pageKey, normalizeColor } from './lib/annotations.js';

const panelUrl = chrome.runtime.getURL('panel.html');
const optionsUrl = chrome.runtime.getURL('options.html');
let optionsOpening;
let originalTask = null, externalBusy = 0;
const ready = chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).then(async () => { await chrome.storage.local.remove('yuqueImageConnection'); await recoverInterruptedJobs(); if (typeof indexedDB !== 'undefined') await recoverImages().catch(() => {}); const { originalCapture } = await originalState(); if (originalCapture?.status === 'running') await chrome.storage.local.set({ originalCapture: { ...originalCapture, status: 'error', error: '上次获取已中断，请重新获取原文。' } }); });
let queue = Promise.resolve();
let saveQueue = Promise.resolve();
const serialize = work => {
  const result = queue.then(work);
  queue = result.catch(() => {});
  return result;
};
const serializeSave = work => {
  const result = saveQueue.then(work);
  saveQueue = result.catch(() => {});
  return result;
};
const targetName = target => target === 'yuque' ? '语雀' : '飞书';
async function notifyAnnotations(key) {
  const tabs = await chrome.tabs.query({});
  await Promise.allSettled(tabs.map(tab => chrome.tabs.sendMessage(tab.id, { type: 'ANNOTATIONS_CHANGED', pageKey: key })));
}

async function performSaveClip(raw, target, resumeId, imageMode, repoOverride = null) {
  if (!['yuque', 'feishu'].includes(target)) throw new Error('请选择语雀或飞书');
  const clip = normalizeClip(raw);
  const { settings, jobs } = await getState();
  if (!isConnected(settings, target) && !(target === 'yuque' && repoOverride?.repo && repoOverride?.bookId)) return { needsSetup: true, target };
  const resumed = resumeId && jobs.find(job => job.id === resumeId && job.target === target);
  if (resumeId && (!resumed || resumed.status === 'uncertain' || resumed.status === 'pending')) throw new Error('该记录不能直接继续，请先检查保存结果。');
  if (imageNodes(clip.document).length && imageMode === 'links' && !resumeId && jobs.some(job=>job.clip.id===clip.id&&job.target===target&&job.imageMode==='full'&&job.status==='failed'&&job.documentId)) throw new Error('已有部分图文写入，请先从原记录继续处理，避免重复创建正文');
  const destinationSettings = { ...settings[target], ...(repoOverride || {}), ...(resumed?.destinationValues || {}) };
  const effectiveSettings = { ...settings, [target]: destinationSettings };
  const destination = destinationKey(effectiveSettings, target);
  const images = imageNodes(clip.document);
  imageMode = resumed?.imageMode || imageMode || 'full';
  if (images.length && !['full', 'links'].includes(imageMode)) throw new Error('请选择有效的图片保存方式');
  if (images.length && imageMode === 'full') { const retention = await imageRetention(clip); if (retention.summary.blocking) throw new Error(retention.summary.pending ? '正在读取图片，请稍候再保存。' : '有图片尚未保留，请在工作台重试图片后保存。'); }
  const hash = await fingerprint(clip, target, destination, imageMode);
  if (resumed && resumed.status !== 'saved' && resumed.fingerprint !== hash) throw new Error('继续处理需保留原记录内容与目标，请恢复原内容后再试。');
  const existing = (resumed?.fingerprint === hash ? resumed : null) || jobs.find(job => job.clip.id === clip.id && job.target === target && job.fingerprint === hash);
  if (existing?.status === 'saved') return { url: existing.url, target, duplicate: true };
  if (existing?.status === 'uncertain') throw new Error('上次写入结果待核对，请先打开记录中的目标检查。确认后可恢复为新摘录再保存。');
  let job = existing;
  if (!job) {
    const jobClip = images.length ? await freezeImageSnapshot(clip) : clip;
    const skippedImageIds = images.length ? (await imageRetention(jobClip)).skippedIds : [];
    job = { id: crypto.randomUUID(), clip: jobClip, target, fingerprint: hash, ...(images.length ? { imageMode } : {}), ...(skippedImageIds.length ? { skippedImageIds } : {}), nextBlock: 0, createdAt: new Date().toISOString() };
  }
  job.destination = destinationLabel(effectiveSettings, target);
  job.destinationKey = destination;
  job.destinationValues = target === 'yuque' ? { repo: destinationSettings.repo, bookId: destinationSettings.bookId || '', repoName: destinationSettings.repoName || '' } : { mode: destinationSettings.mode, documentUrl: destinationSettings.documentUrl, folderUrl: destinationSettings.folderUrl };
  job.status = 'pending';
  job.error = '';
  const checkpoint = async () => { job.updatedAt = new Date().toISOString(); await putJob(job); };
  await checkpoint();
  try {
    await (target === 'yuque' ? saveYuque(job.clip, destinationSettings, job, checkpoint) : saveFeishu(job.clip, destinationSettings, job, checkpoint));
    job.status = 'saved';
    await checkpoint();
    return { url: job.url, target };
  } catch (error) {
    job.status = error.uncertain ? 'uncertain' : 'failed';
    job.error = error.message;
    await checkpoint();
    throw error;
  }
}

async function saveClip(raw, target, resumeId, imageMode, repoOverride = null) {
  if (originalTask) throw new Error('正在获取原文，请完成后再保存');
  externalBusy++;
  try { return await performSaveClip(raw, target, resumeId, imageMode, repoOverride); } finally { externalBusy--; }
}
async function captureOriginal(message, sender) {
  if (originalTask || externalBusy) throw new Error('当前操作尚未结束，请稍后获取原文');
  const stored = await originalState();
  if (stored.pendingOriginal) throw new Error('请先处理待更新原文');
  if (originalTask) throw new Error('正在获取原文，请稍候');
  let tab;
  if (Number.isInteger(message.tabId) && message.tabId >= 0) tab = await chrome.tabs.get(message.tabId);
  else {
    if (sender.tab) throw new Error('请在想要获取的网页中打开拾句');
    [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  }
  if (!tab?.id || tab.url && !/^https?:\/\//.test(tab.url)) throw new Error('当前页面不支持整页获取，请在普通文章网页中打开拾句');
  if (/\.(?:pdf|png|jpe?g|gif|webp|svg)(?:[?#]|$)/i.test(tab.url || '')) throw new Error('当前页面不支持整页获取，请在普通文章网页中使用');
  if (originalTask || externalBusy) throw new Error('当前操作尚未结束，请稍后获取原文');
  const task = { id: crypto.randomUUID(), tabId: tab.id, sourceUrl: tab.url || '', status: 'running', contextMenu: Boolean(message.contextMenu) };
  originalTask = task;
  let timer;
  const stillCurrent = () => { if (originalTask !== task) throw new Error('获取任务已结束，请重试'); };
  const read = async type => {
    const result = await chrome.tabs.sendMessage(tab.id, { type, expectedUrl: task.sourceUrl }, { frameId: 0 });
    if (!result?.ok) throw new Error(result?.error || '网页连接已失效，请刷新网页后重试');
    if (!/^https?:\/\//.test(result.data?.sourceUrl || '') || task.sourceUrl && result.data.sourceUrl !== task.sourceUrl) throw new Error('来源页面已变化，请重新获取');
    return result.data;
  };
  try {
    await chrome.storage.local.set({ originalCapture: task });
    const work = async () => {
      const before = await read('ORIGINAL_IDENTITY');
      task.sourceUrl = before.sourceUrl;
      const snapshot = await read('ORIGINAL_EXTRACT');
      const afterTab = await chrome.tabs.get(tab.id);
      const after = await read('ORIGINAL_IDENTITY');
      stillCurrent();
      if (afterTab.url && afterTab.url !== task.sourceUrl || before.documentToken !== snapshot.documentToken || before.documentToken !== after.documentToken) throw new Error('来源页面已跳转或刷新，请重新获取');
      return serialize(async () => { stillCurrent(); const clip = normalizeClip({ ...snapshot, id: crypto.randomUUID(), sourceUrl: task.sourceUrl, kind: 'page' }); if (imageNodes(clip.document).length) await prepareImages(clip, { tabId:tab.id, frameId:0, sourceUrl:task.sourceUrl, documentToken:snapshot.documentToken }); stillCurrent(); const result = await stageOriginal(clip); startImages(clip); return result; });
    };
    const result = await Promise.race([work(), new Promise((_, reject) => { timer = setTimeout(() => { if (originalTask === task) originalTask = null; reject(new Error('获取超过10秒，请稍后重试')); }, 10000); })]);
    await chrome.storage.local.set({ originalCapture: { ...task, status: 'ready', articleId: result.id, duplicate: result.duplicate, pendingId: result.pendingId } });
    return { ...result, tabId: tab.id };
  } catch (error) {
    const reason = /Receiving end|Could not establish|No tab|closed/i.test(error.message) ? '网页连接已失效，请刷新网页后重试' : error.message;
    await chrome.storage.local.set({ originalCapture: { ...task, status: 'error', error: reason } }).catch(() => {});
    throw new Error(reason);
  } finally { clearTimeout(timer); if (originalTask === task) originalTask = null; }
}

export function trustedPanel(sender) {
  return sender.id === chrome.runtime.id && sender.url?.split(/[?#]/)[0] === panelUrl;
}

export function trustedOptions(sender) {
  return sender.id === chrome.runtime.id && sender.url?.split(/[?#]/)[0] === optionsUrl;
}
async function openOptions(message) {
  if (['general', 'targets'].includes(message.section)) {
    await chrome.storage.session.set({ optionsNavigation: { id: crypto.randomUUID(), section: message.section, provider: message.provider === 'feishu' ? 'feishu' : 'yuque' } });
  }
  if (optionsOpening) return optionsOpening;
  optionsOpening = (async () => {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['TAB'] });
    const existing = contexts.find(context => context.documentUrl?.split(/[?#]/)[0] === optionsUrl && context.tabId >= 0);
    if (existing) {
      await chrome.tabs.update(existing.tabId, { active: true });
      if (existing.windowId >= 0) await chrome.windows.update(existing.windowId, { focused: true });
    } else await chrome.runtime.openOptionsPage();
    return { opened: true };
  })().finally(() => { optionsOpening = null; });
  return optionsOpening;
}
function contentSource(sender) {
  if (!sender.tab) return null;
  // History API navigation updates tab.url but leaves the initial document's sender.url unchanged.
  // Only top-level documents may use tab.url; frames must retain their own source.
  const url = sender.frameId === 0 ? sender.tab.url || sender.url : sender.url || sender.tab.url;
  return /^https?:/.test(url || '') ? url : null;
}

async function handleMessage(message, sender) {
  await ready;
  if (!message || typeof message.type !== 'string') throw new Error('无效请求');
  if (message.type === 'PUBLIC_SETTINGS') return publicSettings((await getState()).settings);
  if (['ANNOTATIONS_LIST', 'ANNOTATION_UPSERT', 'ANNOTATION_DELETE'].includes(message.type)) {
    const panel = trustedPanel(sender);
    const sourceUrl = contentSource(sender);
    if (!panel && !sourceUrl) throw new Error('请在普通网页中使用划词笔记');
    const key = sourceUrl ? pageKey(sourceUrl) : null;
    if (message.type === 'ANNOTATIONS_LIST') {
      const { annotations } = await getState();
      return panel ? annotations : annotations.filter(item => item.pageKey === key);
    }
    return serialize(async () => {
      const { annotations } = await getState();
      const existing = annotations.find(item => item.id === (message.id || message.annotation?.id));
      if (existing && !panel && existing.pageKey !== key) throw new Error('只能修改当前网页的笔记');
      if (message.type === 'ANNOTATION_DELETE') {
        if (!existing) throw new Error('这条标记已经不存在');
        await writeAnnotations(annotations.filter(item => item.id !== existing.id));
        const { workspace } = await getState(); if (workspace.noteDrafts?.[existing.id]) { delete workspace.noteDrafts[existing.id]; await chrome.storage.local.set({ workspace }); }
        await notifyAnnotations(existing.pageKey);
        return { deleted: true };
      }
      let annotation;
      if (panel) {
        if (!existing) throw new Error('这条笔记已不存在，请在网页中重新划选');
        const color = normalizeColor(message.color);
        const clip = normalizeClip({ ...existing.clip, note: message.note });
        if (clip.note === existing.clip.note && color === existing.color) return existing;
        annotation = { ...existing, clip, color, updatedAt: new Date().toISOString() };
      } else {
        annotation = normalizeAnnotation(message.annotation || {}, sourceUrl);
        if (existing) annotation = { ...annotation, createdAt: existing.createdAt };
      }
      const next = [annotation, ...annotations.filter(item => item.id !== annotation.id)];
      await writeAnnotations(next);
      await notifyAnnotations(annotation.pageKey);
      return annotation;
    });
  }
  if (message.type === 'CAPTURE') {
    const sourceUrl = contentSource(sender);
    if (!sourceUrl) throw new Error('请在普通网页中选中文字');
    const clip = normalizeClip({ ...message.clip, sourceUrl });
    if (imageNodes(clip.document).length) await prepareImages(clip, { tabId:sender.tab.id, frameId:sender.frameId||0, sourceUrl });
    const result = await serialize(async () => {
      const current = await getState();
      if (current.draft && current.draftEdited) {
        const pendingCapture = { id: crypto.randomUUID(), clip, target: ['yuque', 'feishu'].includes(message.target) ? message.target : null };
        await chrome.storage.local.set({ pendingCapture });
        return { needsReplace: true };
      }
      await chrome.storage.local.set({ draft: clip, draftEdited: false, pendingCapture: null, workspace: { ...current.workspace, view: 'clip', resumeId: null, ...(['yuque', 'feishu'].includes(message.target) ? { target: message.target } : {}) } });
      return { captured: true };
    });
    startImages(clip);
    if (result.needsReplace) return result;
    if (imageNodes(clip.document).length) return { ...result, needsImageReview:true };
    return message.target ? serializeSave(() => saveClip(clip, message.target)) : result;
  }
  if (message.type === 'YUQUE_REPOS') {
    if (!trustedOptions(sender) && !trustedPanel(sender)) throw new Error('此操作只能在拾句设置页或工作台中执行');
    const session = createYuqueImages();
    try { return await session.listRepos(); } finally { await session.close(); }
  }
  if (message.type === 'SET_YUQUE_REPO') {
    if (!trustedPanel(sender) && !trustedOptions(sender)) throw new Error('此操作只能在拾句设置页或工作台中执行');
    if (typeof message.repo !== 'string' || !message.repo.trim()) throw new Error('请选择语雀知识库');
    if (!/^[1-9]\d{0,19}$/.test(String(message.bookId || ''))) throw new Error('知识库编号无效，请重新选择');
    return serialize(async () => {
      const { settings } = await getState();
      const next = normalizeSettings({ ...settings, yuque: { ...settings.yuque, repo: message.repo, bookId: String(message.bookId), repoName: typeof message.repoName === 'string' ? message.repoName : '' } });
      await chrome.storage.local.set({ settings: next });
      const tabs = await chrome.tabs.query({});
      await Promise.allSettled(tabs.map(tab => chrome.tabs.sendMessage(tab.id, { type: 'PUBLIC_SETTINGS_CHANGED', settings: publicSettings(next) })));
      return { settings: workbenchSettings(next) };
    });
  }
  if (['OPTIONS_STATE', 'SETTINGS', 'TEST_CONNECTION'].includes(message.type)) {
    if (!trustedOptions(sender)) throw new Error('此操作只能在拾句扩展选项页中执行');
    if (message.type === 'OPTIONS_STATE') return { settings: (await getState()).settings, navigation: (await chrome.storage.session.get('optionsNavigation')).optionsNavigation };
    if (message.type === 'SETTINGS') return serialize(async () => {
      const { settings: previous } = await getState();
      const { group, values } = message;
      if (!['general', 'yuque', 'feishu'].includes(group) || !values || typeof values !== 'object') throw new Error('请选择有效的配置分类');
      if (group === 'yuque' && externalBusy) throw new Error('正在保存，请完成后再更改语雀连接。');
      const patch = group === 'general' ? Object.fromEntries(['toolbar', 'ball'].filter(key => key in values).map(key => [key, values[key]])) : { [group]: { ...previous[group], ...Object.fromEntries(Object.keys(previous[group]).filter(key => key in values).map(key => [key, values[key]])) } };
      const settings = normalizeSettings({ ...previous, ...patch });
      await chrome.storage.local.set({ settings });
      const tabs = await chrome.tabs.query({});
      await Promise.allSettled(tabs.map(tab => chrome.tabs.sendMessage(tab.id, { type: 'PUBLIC_SETTINGS_CHANGED', settings: publicSettings(settings) })));
      return { settings };
    });
    const { settings } = await getState();
    if (!['yuque', 'feishu'].includes(message.target)) throw new Error('无效平台');
    if (!isConnected(settings, message.target)) throw new Error(`请先填写并保存${targetName(message.target)}连接设置`);
    if (message.target === 'yuque' && !settings.yuque.token) {
      const session = createYuqueImages();
      try {
        const { user, repos } = await session.listRepos();
        if (settings.yuque.repo && !repos.some(item => item.namespace === settings.yuque.repo)) throw new Error('当前登录账户中未找到已选知识库，请重新选择');
        return { message: `已连接 ${user.name || user.login || '语雀'}。保存时使用当前浏览器语雀登录态。` };
      } finally { await session.close(); }
    }
    return { message: await testConnection(message.target, settings) };
  }
  if (!trustedPanel(sender)) throw new Error('此操作只能在拾句工作台中执行');
  switch (message.type) {
    case 'STATE': { const state = await getState(); return { ...state, settings: workbenchSettings(state.settings) }; }
    case 'OPEN_OPTIONS': return openOptions(message);
    case 'IMAGE_RETRY': return retryImage(message.id);
    case 'ORIGINAL_CAPTURE': return captureOriginal(message, sender);
    case 'ORIGINAL_UPDATE': return serialize(() => updateOriginal(message.id, message.patch, message.expectedRevision));
    case 'ORIGINAL_ACCEPT': return serialize(() => acceptOriginal(message.pendingId));
    case 'ORIGINAL_REJECT': return serialize(() => rejectOriginal(message.pendingId));
    case 'ORIGINAL_DELETE': return serialize(() => deleteOriginal(message.id));
    case 'ORIGINAL_WORKSPACE': return serialize(() => originalWorkspace(message.patch));
    case 'ORIGINAL_SAVE': {
      if (originalTask || (await originalState()).pendingOriginal) throw new Error('请先完成原文获取或更新');
      const { originals } = await originalState();
      const article = originals.find(item => item.id === message.id);
      if (!article) throw new Error('这篇原文已删除');
      if (article.noteDraft !== null) throw new Error('请先完成或取消当前笔记编辑');
      let repoOverride = null;
      if (message.target === 'yuque' && message.yuqueRepo) {
        const value = message.yuqueRepo, repo = parseRepo(value.repo);
        if (!/^[1-9]\d{0,19}$/.test(String(value.bookId || ''))) throw new Error('请重新选择语雀知识库');
        repoOverride = { repo, bookId: String(value.bookId), repoName: String(value.repoName || '').slice(0, 140) };
      }
      return serializeSave(() => saveClip(structuredClone(article), message.target, message.resumeId, message.imageMode, repoOverride));
    }
    case 'ORIGINAL_SAVE_RECORD': {
      const { jobs } = await getState();
      const job = jobs.find(item => item.id === message.jobId && item.clip.kind === 'page');
      if (!job) throw new Error('原文记录不存在');
      if (job.status === 'uncertain' || job.status === 'pending') throw new Error('请先核对目标，不能直接重复保存');
      return serializeSave(() => saveClip(job.clip, job.target, job.id, job.imageMode));
    }

    case 'NOTE_DRAFT': return serialize(async () => {
      const { annotations, workspace } = await getState();
      if (!/^[\w-]{1,80}$/.test(String(message.id || ''))) throw new Error('笔记标识无效');
      const drafts = { ...(workspace.noteDrafts || {}) };
      if (message.draft === null) delete drafts[message.id];
      else {
        if (!annotations.some(item => item.id === message.id)) throw new Error('这处标注已删除');
        if (typeof message.draft?.note !== 'string' || message.draft.note.length > 20000) throw new Error('批注草稿最多20,000字符');
        drafts[message.id] = { note: message.draft.note, color: normalizeColor(message.draft.color) };
      }
      await chrome.storage.local.set({ workspace: { ...workspace, noteDrafts: drafts } }); return { saved: true };
    });
    case 'WORKSPACE': return serialize(async () => {
      const { workspace } = await getState(); const patch = {};
      if (['clip', 'originals', 'notes', 'history'].includes(message.patch?.view)) patch.view = message.patch.view;
      if (['yuque', 'feishu'].includes(message.patch?.target)) patch.target = message.patch.target;
      if (message.patch?.resumeId === null || typeof message.patch?.resumeId === 'string' && /^[\w-]{1,80}$/.test(message.patch.resumeId)) patch.resumeId = message.patch.resumeId;
      if (message.patch?.scroll && typeof message.patch.scroll === 'object') patch.scroll = Object.fromEntries(['clip', 'originals', 'notes', 'history'].map(key => [key, Math.max(0, Math.min(1000000, Number(message.patch.scroll[key]) || 0))]));
      const draftRepo = message.patch?.draftYuque;
      if (draftRepo === null) patch.draftYuque = null;
      else if (draftRepo && typeof draftRepo === 'object' && /^[\w-]{1,80}$/.test(String(draftRepo.draftId || '')) && /^[\w-]+\/[\w-]+$/.test(String(draftRepo.repo || '')) && /^[1-9]\d{0,19}$/.test(String(draftRepo.bookId || ''))) patch.draftYuque = { draftId: String(draftRepo.draftId), repo: String(draftRepo.repo), bookId: String(draftRepo.bookId), repoName: String(draftRepo.repoName || '').slice(0, 140) };
      if (message.patch?.notesPageKey === null || typeof message.patch?.notesPageKey === 'string' && message.patch.notesPageKey.length <= 8000) patch.notesPageKey = message.patch.notesPageKey;
      for (const key of ['notesQuery', 'notesListQuery']) if (typeof message.patch?.[key] === 'string') patch[key] = message.patch[key].slice(0, 200);
      if (Number.isFinite(message.patch?.notesListScroll)) patch.notesListScroll = Math.max(0, Math.min(1000000, message.patch.notesListScroll));
      const noteTargets = message.patch?.noteTargets;
      if (noteTargets && typeof noteTargets === 'object' && !Array.isArray(noteTargets)) {
        const clean = {};
        for (const [id, value] of Object.entries(noteTargets)) {
          if (!/^[\w-]{1,80}$/.test(id) || !value || typeof value !== 'object') continue;
          if (!/^[\w-]+\/[\w-]+$/.test(String(value.repo || '')) || !/^[1-9]\d{0,19}$/.test(String(value.bookId || ''))) continue;
          clean[id] = { repo: String(value.repo), bookId: String(value.bookId), repoName: String(value.repoName || '').slice(0, 140) };
        }
        patch.noteTargets = { ...(workspace.noteTargets || {}), ...clean };
      }
      await chrome.storage.local.set({ workspace: { ...workspace, ...patch } }); return { saved: true };
    });
    case 'EDIT_STARTED': return serialize(async () => { const { draft } = await getState(); if (draft?.id === message.id) await chrome.storage.local.set({ draftEdited: true }); return { marked: true }; });
    case 'REJECT_CAPTURE': return serialize(async () => { const { pendingCapture } = await getState(); if (pendingCapture?.id === message.id) await chrome.storage.local.set({ pendingCapture: null }); return { rejected: true }; });
    case 'ACCEPT_CAPTURE': return serialize(async () => {
      const { pendingCapture, workspace } = await getState(); if (!pendingCapture || pendingCapture.id !== message.id) throw new Error('待处理剪藏已变化，请重新选择');
      await chrome.storage.local.set({ draft: pendingCapture.clip, draftEdited: false, pendingCapture: null, workspace: { ...workspace, view: 'clip', resumeId: null, ...(pendingCapture.target ? { target: pendingCapture.target } : {}) } });
      return pendingCapture;
    });
    case 'ANNOTATION_TO_DRAFT': return serialize(async () => {
      const { annotations, draft, draftEdited, workspace } = await getState();
      if (draft && draftEdited && !message.replaceConfirmed) throw new Error('请先确认替换当前草稿');
      const item = annotations.find(annotation => annotation.id === message.id);
      if (!item) throw new Error('这条笔记已不存在');
      await chrome.storage.local.set({ draft: item.clip, draftEdited: false, pendingCapture: null, workspace: { ...workspace, view: 'clip', resumeId: null } });
      return item.clip;
    });
    case 'DRAFT': return serialize(async () => {
      const clip = normalizeClip(message.clip);
      const current = await getState();
      if (message.expectedId && current.draft?.id !== message.expectedId) throw new Error('当前剪藏已变化，输入仍保留，请先处理待替换内容');
      await chrome.storage.local.set({ draft: clip, draftEdited: true });
      return clip;
    });
    case 'NOTE_EXPORT': {
      const { annotations } = await getState();
      const item = annotations.find(annotation => annotation.id === message.id);
      if (!item) throw new Error('这条笔记已不存在');
      const value = message.yuqueRepo || {};
      const repo = parseRepo(value.repo);
      if (!/^[1-9]\d{0,19}$/.test(String(value.bookId || ''))) throw new Error('知识库编号无效，请重新选择知识库');
      const clip = normalizeClip({ ...item.clip, note: item.clip.note });
      return serializeSave(() => saveClip(clip, 'yuque', null, 'full', { repo, bookId: String(value.bookId), repoName: String(value.repoName || '').slice(0, 140) }));
    }
    case 'SAVE': {
      const clip = normalizeClip(message.clip);
      await serialize(async () => { const current = await getState(); if (message.expectedId && (current.draft?.id !== message.expectedId || clip.id !== message.expectedId)) throw new Error('当前剪藏已变化，请检查内容后再保存'); await chrome.storage.local.set({ draft: clip }); });
      let repoOverride = null;
      if (message.target === 'yuque' && message.yuqueRepo) {
        const value = message.yuqueRepo;
        const repo = parseRepo(value?.repo);
        if (!/^[1-9]\d{0,19}$/.test(String(value?.bookId || ''))) throw new Error('知识库编号无效，请重新选择知识库');
        repoOverride = { repo, bookId: String(value.bookId), repoName: String(value.repoName || '').slice(0, 140) };
      }
      return serializeSave(() => saveClip(clip, message.target, message.resumeId, message.imageMode, repoOverride));
    }
    case 'RESTORE': return serialize(async () => {
      const { jobs, draft, draftEdited, workspace } = await getState();
      if (draft && draftEdited && !message.replaceConfirmed) throw new Error('请先确认替换当前草稿');
      const job = jobs.find(item => item.id === message.id);
      if (!job) throw new Error('该摘录记录已不存在');
      if (job.status === 'pending') throw new Error('保存尚未完成，请稍后查看');
      if (job.status === 'uncertain' && !message.asNew) throw new Error('该记录待核对，请先检查目标');
      // Older releases retained the created document and checkpoint but no destination snapshot.
      // Bind an explicit resume to that known document, never to a newly configured folder.
      if (!message.asNew && job.status === 'failed' && job.target === 'feishu' && job.documentId && !job.destinationValues && job.url) {
        const original = parseFeishuUrl(job.url);
        if (original.token !== job.documentId) throw new Error('原记录的文档信息不一致，请先检查目标');
        job.destinationValues = { mode: 'append', documentUrl: original.url, folderUrl: '' };
        job.destinationKey = destinationKey({ feishu: job.destinationValues }, 'feishu');
        job.destination = `${original.url} · 继续原文档`;
        job.fingerprint = await fingerprint(job.clip, 'feishu', job.destinationKey);
        await putJob(job);
      }

      const clip = { ...job.clip, id: message.asNew ? crypto.randomUUID() : job.clip.id };
      await chrome.storage.local.set({ draft: clip, draftEdited: false, pendingCapture: null, workspace: { ...workspace, view: 'clip', target: job.target, resumeId: !message.asNew && job.status === 'failed' ? job.id : null } });
      return clip;
    });
    case 'CLEAR_HISTORY': return serializeSave(async () => { await clearJobs(); return { cleared: true }; });
    default: throw new Error('不支持的操作');
  }
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  // Opening must happen synchronously while the user's click gesture is active.
  if (message?.type === 'CAPTURE' && message.openPanel && sender.tab?.id) {
    chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {});
  }
  handleMessage(message, sender).then(data => respond({ ok: true, data })).catch(error => respond({ ok: false, error: error.message, uncertain: Boolean(error.uncertain) }));
  return true;
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'original-page', title: '拾句 · 获取整页内容', contexts: ['page'], documentUrlPatterns: ['http://*/*', 'https://*/*'] });
    chrome.contextMenus.create({ id: 'shiju', title: '拾句 · 保存选中文字', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'yuque', parentId: 'shiju', title: '保存到语雀', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'feishu', parentId: 'shiju', title: '保存到飞书', contexts: ['selection'] });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'original-page' && tab?.id) {
    chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
    ready.then(() => serialize(async () => { const { workspace } = await getState(); await chrome.storage.local.set({ workspace: { ...workspace, view: 'originals' } }); })).then(() => captureOriginal({ tabId: tab.id, contextMenu: true }, { id: chrome.runtime.id, url: panelUrl })).catch(() => {});
    return;
  }
  if (!['yuque', 'feishu'].includes(info.menuItemId) || !tab?.id) return;
  chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
  const clip = { title: (tab.title || '网页摘录').slice(0, 120), sourceTitle: (tab.title || '').slice(0, 500), text: info.selectionText, sourceUrl: info.frameUrl || info.pageUrl, capturedAt: new Date().toISOString() };
  (async () => { try { const snapshot = await chrome.tabs.sendMessage(tab.id, { type:'SELECTION_SNAPSHOT' }, { frameId:info.frameId||0 }); if (snapshot?.ok && snapshot.data?.document) { clip.document=snapshot.data.document; clip.kind='selection'; } } catch {} await handleMessage({ type:'CAPTURE', clip, target:info.menuItemId }, { tab, frameId:info.frameId||0, url:info.frameUrl||info.pageUrl }); })().catch(() => {});
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command !== 'capture-selection' || !tab?.id) return;
  chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
  chrome.tabs.sendMessage(tab.id, { type: 'CAPTURE_SELECTION' }).catch(() => {});
});

let imageCleanTimer;
chrome.storage.onChanged?.addListener((changes, area) => { if (area !== 'local' || !['draft','pendingCapture','originals','pendingOriginal','jobs','annotations'].some(key => key in changes) || typeof indexedDB === 'undefined') return; clearTimeout(imageCleanTimer); imageCleanTimer=setTimeout(() => cleanImages().catch(() => {}), 1000); });
