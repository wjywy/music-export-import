(() => {
  if (globalThis.__shijuInstalled) return;
  const runtime = globalThis.chrome?.runtime;
  if (!runtime?.id || typeof runtime.onMessage?.addListener !== 'function') return;
  globalThis.__shijuInstalled = true;
  const anchors = globalThis.__shijuAnchors;
  const colorTools = globalThis.__shijuColors;
  const colors = colorTools.presets;
  const paletteGap = 10;
  let activeColor = 'yellow', customStyle, customRules = '', paletteEscape = false;
  const customHighlights = new Set();
  let markControl, copyControl, copyStatus, copyBusy = false, copyTimer;
  let hideColorPalette = () => {}, showColorPalette = () => {}, positionColorPalette = () => {}, finishCustomPicker = () => false, syncColorControls = () => {}, setMarkerBusy = () => {};
  let config = { toolbar: true, ball: true, ballMode: 'edge', motion: 'system', yuque: false, feishu: false };
  let captured = null;
  let capturedRange;
  let host; let shadow; let bar; let palette; let editor;
  let noteText; let noteSave; let noteCancel; let noteError;
  let noteItem = null;
  let noteRange;
  let annotations = [];
  let liveRanges = new Map();
  let busy = false; let noteBusy = false;
  let selectionTimer; let toastTimer; let renderTimer; let matchDeadline;
  let lastUrl = location.href;
  let refreshVersion = 0;
  let pageNotes;
  let deleteConfirm;
  let pageNotesInitialized = false;
  let selectedNoteId = null;
  let focusTimer;
  let positionFrame;
  let toolsFrame;
  let hideToolbarTip = () => {};
  const pointer = globalThis.__shijuInstallHighlightPointer({ ranges: () => liveRanges, insideUI: event => event.composedPath().includes(host) });
  const newId = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), byte => byte.toString(16).padStart(2, '0')).join('');
  const keyFor = value => { const url = new URL(value); if (!/^#!?\//.test(url.hash)) url.hash = ''; return url.href; };
  async function request(type, payload = {}) {
    return globalThis.__shijuMessaging.send(type, payload);
  }
  function applyConfig(data) { config = data; if (!host && window === window.top && config.ball !== false) mount(); pageNotes?.preferences(config); if (!config.toolbar && bar) hideBar(); }
  const refreshConfig = () => request('PUBLIC_SETTINGS').then(applyConfig).catch(() => {});
  refreshConfig();

  function button(text, label, handler) {
    const node = document.createElement('button'); node.type = 'button'; node.textContent = text; node.setAttribute('aria-label', label); node.addEventListener('click', handler); return node;
  }
  function mount() {
    if (host?.isConnected) return;
    host = document.createElement('shiju-clipper');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:0;top:0;';
    shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = `:host{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;color:#25332d;font-size:13px;line-height:1.5}*{box-sizing:border-box}[hidden]{display:none!important}button,a,textarea{font:inherit}button{border:0;border-radius:8px;background:transparent;color:#25332d;padding:9px 10px;cursor:pointer;white-space:nowrap;min-height:38px}button:hover{background:#edf2ec}button:active{transform:scale(.98)}button:focus-visible,a:focus-visible,textarea:focus-visible{outline:2px solid #285942;outline-offset:2px}button:disabled{opacity:.5;cursor:wait}
.bar{position:fixed;display:flex;align-items:center;gap:2px;padding:3px;background:#fff;border:1px solid #e6e9e6;border-radius:8px;box-shadow:0 3px 12px #25332d12;max-width:calc(100vw - 16px)}
.bar button{display:inline-flex;align-items:center;justify-content:center;flex:none;width:32px;height:32px;min-height:32px;padding:0;border-radius:5px;color:#4d5751;line-height:1;font-size:13px}
.bar button:hover{background:#f1f4f0;color:#285942}.bar button:focus-visible{outline-offset:-2px}.bar button:disabled{cursor:wait}.bar button svg{pointer-events:none}.bar .mark-control{position:relative}.mark-control::after{content:"";position:absolute;bottom:4px;left:10px;width:12px;height:2px;background:var(--mark-color,#f9e797);border-radius:1px}.bar-copy-status{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
.bar .destination{width:auto;min-width:42px;padding:0 7px;color:#343c36}.bar .dismiss{color:#858d87}
.bar-separator{flex:none;width:1px;height:16px;margin:0 3px;background:#e9ece8}
.bar-tip{position:fixed;z-index:1;max-width:calc(100vw - 16px);pointer-events:none;white-space:nowrap;background:#343c36;color:#fff;border-radius:5px;padding:5px 8px;font-size:12px;line-height:1.5}
.color-palette{position:fixed;z-index:6;display:flex;align-items:center;gap:4px;padding:7px;border:1px solid #e6e9e6;border-radius:10px;background:#fff;box-shadow:0 4px 16px #25332d18;max-width:calc(100vw - 16px)}.color-palette::after{content:"";position:absolute;left:-1px;right:-1px;height:${paletteGap + 2}px}.color-palette[data-side=above]::after{top:calc(100% - 1px)}.color-palette[data-side=below]::after{bottom:calc(100% - 1px)}.color-palette button,.color-custom{position:relative;display:flex;align-items:center;justify-content:center;width:32px;height:32px;min-height:32px;padding:4px;border:0;border-radius:50%;background:transparent}.color-palette button::before{content:"";width:24px;height:24px;border-radius:50%;background:var(--swatch)}.color-palette button[aria-checked=true]::before{outline:2px solid #343c36;outline-offset:2px}.color-palette button:hover{background:#f1f4f0}.color-custom{color:#626b65;border:1px dashed #c9d0c9;cursor:pointer;margin-left:3px}.color-custom input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer}.color-custom[data-selected=true]{background:var(--custom-color);color:var(--custom-ink);outline:2px solid #343c36;outline-offset:2px;border:0}.color-custom:focus-within{outline:2px solid #285942;outline-offset:2px}
@media(hover:none){.color-palette button,.color-custom{width:44px;height:44px;min-height:44px}.color-palette button::before{width:30px;height:30px}.bar{display:grid;grid-template-columns:repeat(5,44px)}.bar-separator{display:none}.bar .yuque{grid-row:2;grid-column:1 / span 2}.bar .feishu{grid-row:2;grid-column:3 / span 2}.bar .edit-action{grid-row:1;grid-column:4}.bar .dismiss{grid-row:1;grid-column:5}.bar button{width:44px;height:44px;min-height:44px}.bar .destination{width:auto;min-width:44px}}
.notebook{background:#fff;border-radius:8px;padding:16px;color:#25332d}.notebook textarea{width:100%;resize:vertical;line-height:1.75;color:#25332d;background:#fff}.note-actions{display:flex;align-items:center;gap:10px}.primary{background:#285942;color:#fff}.primary:hover{background:#204d38}.primary:disabled{background:#b6d5c1;opacity:1;cursor:default}.toast{position:fixed;right:18px;bottom:22px;width:min(350px,calc(100vw - 36px));border-radius:12px;background:#25332d;color:#f6f5f0;padding:14px 16px;box-shadow:0 6px 24px #0002}.toast a{color:#dceccf;text-decoration:underline;margin-left:10px}.toast p{margin:0;overflow-wrap:anywhere}@media(prefers-reduced-motion:reduce){button:active{transform:none}}`;
    bar = document.createElement('div'); bar.className = 'bar'; bar.hidden = true; bar.setAttribute('role', 'toolbar'); bar.setAttribute('aria-label', '保存与标记选中文字');
    const tip = document.createElement('div'); tip.className = 'bar-tip'; tip.id = 'shiju-selection-tip'; tip.setAttribute('role', 'tooltip'); tip.hidden = true;
    let tipTimer; let tipControl;
    const hideTip = () => { clearTimeout(tipTimer); tip.hidden = true; tipControl?.removeAttribute('aria-describedby'); tipControl = null; };
    hideToolbarTip = hideTip;
    const showTip = control => {
      if (bar.hidden || control.disabled || !control.isConnected) return;
      tipControl = control; tip.textContent = control.getAttribute('aria-label'); tip.hidden = false;
      control.setAttribute('aria-describedby', tip.id);
      const trigger = control.getBoundingClientRect(), box = tip.getBoundingClientRect();
      tip.style.left = `${Math.max(8, Math.min(trigger.left + (trigger.width - box.width) / 2, innerWidth - box.width - 8))}px`;
      const below = trigger.bottom + 10;
      tip.style.top = `${Math.max(8, Math.min(below + box.height <= innerHeight - 8 ? below : trigger.top - box.height - 10, innerHeight - box.height - 8))}px`;
    };
    const addAction = (text, label, icon, handler, className = '') => {
      const control = button(text, label, handler); control.className = className;
      if (icon) control.append(globalThis.__shijuNoteIcon(icon));
      control.addEventListener('pointerenter', event => { if (event.pointerType === 'touch') return; hideTip(); tipTimer = setTimeout(() => showTip(control), 350); });
      control.addEventListener('pointerleave', hideTip);
      control.addEventListener('focus', () => { hideTip(); if (control.matches(':focus-visible')) showTip(control); });
      control.addEventListener('blur', hideTip);
      bar.append(control); return control;
    };
    const separate = () => { const line = document.createElement('span'); line.className = 'bar-separator'; line.setAttribute('aria-hidden', 'true'); bar.append(line); };
    markControl = addAction('', '选择高亮颜色', 'highlight', event => showColorPalette(event.detail === 0), 'mark-control');
    addAction('', '为选中文字写笔记', 'comment', () => annotate(true));
    copyControl = addAction('', '复制选中文字', 'copy', copySelection);
    copyStatus = document.createElement('span'); copyStatus.className = 'bar-copy-status'; copyStatus.setAttribute('role', 'status'); copyStatus.setAttribute('aria-live', 'polite'); bar.append(copyStatus);
    separate();
    separate();
    for (const [target, text] of [['yuque', '语雀'], ['feishu', '飞书']]) addAction(text, `保存到${text}`, null, () => capture(target), `destination ${target}`);
    separate();
    addAction('', '关闭划选菜单', 'close', () => { hideBar(); }, 'dismiss');
    bar.append(tip);
    bar.addEventListener('pointerdown', event => { hideTip(); if (event.target.tagName !== 'INPUT') event.preventDefault(); });
    bar.addEventListener('click', hideTip);
    bar.addEventListener('keydown', event => {
      if (event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key === 'Escape') { hideTip(); hideBar(); event.preventDefault(); return; }
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      const controls = [...bar.querySelectorAll(':scope > button:not(:disabled)')];
      if (!controls.length) return;
      const index = controls.indexOf(shadow.activeElement);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? controls.length - 1 : (index + (event.key === 'ArrowLeft' ? -1 : 1) + controls.length) % controls.length;
      event.preventDefault(); controls[next].focus({ preventScroll: true });
    });
    palette = document.createElement('div'); palette.className = 'color-palette'; palette.hidden = true; palette.setAttribute('role', 'dialog'); palette.setAttribute('aria-label', '高亮颜色');
    markControl.setAttribute('aria-haspopup', 'dialog'); markControl.setAttribute('aria-expanded', 'false');
    let paletteShowTimer, paletteHideTimer, customChoosing = false;
    const cancelPaletteHide = () => clearTimeout(paletteHideTimer);
    hideColorPalette = (focus = false) => { clearTimeout(paletteShowTimer); cancelPaletteHide(); customChoosing = false; palette.hidden = true; markControl.setAttribute('aria-expanded', 'false'); if (focus) markControl.focus({ preventScroll: true }); };
    const deferPaletteHide = () => { clearTimeout(paletteShowTimer); cancelPaletteHide(); if (!customChoosing) paletteHideTimer = setTimeout(() => hideColorPalette(), 150); };
    positionColorPalette = () => {
      if (palette.hidden) return;
      const trigger = markControl.getBoundingClientRect(), box = palette.getBoundingClientRect(), above = trigger.top - box.height - paletteGap;
      palette.style.left = `${Math.max(8, Math.min(trigger.left - 6, innerWidth - box.width - 8))}px`;
      const top = Math.max(8, Math.min(above >= 8 ? above : trigger.bottom + paletteGap, innerHeight - box.height - 8));
      palette.style.top = `${top}px`; palette.dataset.side = top + box.height <= trigger.top ? 'above' : 'below';
    };
    showColorPalette = (focus = false) => {
      clearTimeout(paletteShowTimer); cancelPaletteHide(); if (bar.hidden || busy || !captured) return;
      hideTip(); syncColorControls(); palette.hidden = false; markControl.setAttribute('aria-expanded', 'true'); positionColorPalette();
      if (focus) (palette.querySelector('[aria-checked=true]') || palette.querySelector('input[type=color]')).focus({ preventScroll: true });
    };
    const swatches = document.createElement('div'); swatches.setAttribute('role', 'radiogroup'); swatches.setAttribute('aria-label', '常用高亮颜色'); swatches.style.cssText = 'display:flex;gap:4px'; palette.append(swatches);
    for (const [value, [name, hex]] of Object.entries(colors)) {
      const swatch = button('', `${name}高亮`, () => annotate(false, value)); swatch.setAttribute('role', 'radio'); swatch.dataset.color = value; swatch.style.setProperty('--swatch', hex); swatches.append(swatch);
    }
    const custom = document.createElement('label'); custom.className = 'color-custom'; custom.title = '自定义颜色'; custom.append(__shijuNoteIcon('plus'));
    const customColor = document.createElement('input'); customColor.type = 'color'; customColor.setAttribute('aria-label', '自定义高亮颜色');
    customColor.addEventListener('pointerdown', () => { customChoosing = true; cancelPaletteHide(); });
    customColor.addEventListener('keydown', event => { if (['Enter', ' '].includes(event.key)) { customChoosing = true; cancelPaletteHide(); } });
    customColor.addEventListener('change', () => { customChoosing = false; annotate(false, customColor.value); });
    finishCustomPicker = () => { if (!customChoosing || palette.hidden) return false; customChoosing = false; cancelPaletteHide(); customColor.focus({ preventScroll: true }); return true; };
    custom.append(customColor); palette.append(custom);
    syncColorControls = () => { markControl.style.setProperty('--mark-color', colorTools.hex(activeColor)); customColor.value = colorTools.hex(activeColor); custom.dataset.selected = String(activeColor.startsWith('#')); custom.style.setProperty('--custom-color', colorTools.hex(activeColor)); custom.style.setProperty('--custom-ink', colorTools.ink(activeColor)); for (const swatch of palette.querySelectorAll('[role=radio]')) swatch.setAttribute('aria-checked', String(swatch.dataset.color === activeColor)); };
    syncColorControls();
    setMarkerBusy = value => { palette.setAttribute('aria-busy', String(value)); markControl.disabled = value; for (const control of palette.querySelectorAll('button,input')) control.disabled = value; };
    markControl.addEventListener('pointerenter', event => { if (event.pointerType === 'touch') return; cancelPaletteHide(); paletteShowTimer = setTimeout(() => showColorPalette(), 250); });
    markControl.addEventListener('pointerleave', deferPaletteHide);
    palette.addEventListener('pointerenter', cancelPaletteHide); palette.addEventListener('pointerleave', deferPaletteHide);
    palette.addEventListener('focusout', () => queueMicrotask(() => { if (!customChoosing && !palette.contains(shadow.activeElement) && shadow.activeElement !== markControl) hideColorPalette(); }));
    palette.addEventListener('pointerdown', event => { if (event.target !== customColor) event.preventDefault(); });
    palette.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); paletteEscape = true; hideColorPalette(true); return; }
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key) || event.target === customColor) return;
      const controls = [...palette.querySelectorAll('[role=radio]')], index = controls.indexOf(shadow.activeElement);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? controls.length - 1 : (index + (event.key === 'ArrowLeft' ? -1 : 1) + controls.length) % controls.length;
      event.preventDefault(); event.stopPropagation(); controls[next].focus({ preventScroll: true });
    });
    markControl.addEventListener('keydown', event => { if (event.key === 'ArrowDown') { event.preventDefault(); showColorPalette(true); } });
    bar.append(palette);
    for (const type of ['pointerdown', 'pointerup', 'pointermove', 'pointerover', 'pointerout', 'mousedown', 'mouseup', 'mousemove', 'mouseover', 'mouseout', 'click', 'dblclick']) shadow.addEventListener(type, event => event.stopPropagation());
    const toast = document.createElement('div'); toast.className = 'toast'; toast.hidden = true; toast.setAttribute('role', 'status'); toast.setAttribute('aria-live', 'polite');
    editor = document.createElement('div'); editor.className = 'notebook'; editor.hidden = true; editor.setAttribute('role', 'dialog'); editor.setAttribute('aria-label', '网页划词笔记');
    noteText = document.createElement('textarea'); noteText.id = 'shiju-note-text'; noteText.maxLength = 20000; noteText.placeholder = '写下你的想法…'; noteText.setAttribute('aria-label', '我的笔记');
    noteText.addEventListener('input', () => { noteError.textContent = ''; updateSaveState(); });
    noteText.addEventListener('keydown', event => {
      if (event.key === 'Enter' && (event.metaKey || event.ctrlKey) && !event.isComposing && event.keyCode !== 229) { event.preventDefault(); if (!noteSave.disabled) saveAnnotation(); }
    });
    const actions = document.createElement('div'); actions.className = 'note-actions';
    noteSave = button('保存', '保存划词笔记', saveAnnotation); noteSave.className = 'primary'; noteSave.title = '保存（⌘ / Ctrl + Enter）';
    noteCancel = button('取消', '关闭笔记编辑', () => closeNoteEditor()); noteCancel.className = 'cancel';
    noteError = document.createElement('p'); noteError.className = 'note-error'; noteError.setAttribute('role', 'status');
    actions.append(noteSave, noteCancel); editor.append(noteText, actions, noteError);
    shadow.append(style, bar, toast); document.documentElement.append(host);
    pageNotes = globalThis.__shijuCreateNotesSidebar({ shadow, editor, onLocate: locateNote, onEdit: editSidebarNote, onDelete: deleteSidebarNote, onCollapse: collapseNotes, getSourceTop: id => { const range = liveRanges.get(id) || (id === noteItem?.id ? noteRange : null); return range?.startContainer.isConnected ? range.getBoundingClientRect().top : null; } });
    pageNotes.preferences(config);
    deleteConfirm = globalThis.__shijuCreateConfirmPopover(shadow);
  }
  function hideBar() { clearTimeout(selectionTimer); selectionTimer = null; if (toolsFrame) cancelAnimationFrame(toolsFrame); toolsFrame = null; if (bar) bar.hidden = true; hideToolbarTip(); hideColorPalette(); }
  function resetCopyFeedback() { clearTimeout(copyTimer); copyControl?.replaceChildren(__shijuNoteIcon('copy')); if (copyStatus) copyStatus.textContent = ''; }
  async function copySelection() {
    if (copyBusy || busy || !captured) return;
    const clip = captured, text = clip.text; copyBusy = true; copyControl.disabled = true; hideToolbarTip(); hideColorPalette();
    try {
      let copied = false;
      if (navigator.clipboard?.writeText) { try { await navigator.clipboard.writeText(text); copied = true; } catch {} }
      if (!copied) {
        let handled = false;
        const onCopy = event => { if (!event.clipboardData) return; event.preventDefault(); event.stopImmediatePropagation(); event.clipboardData.setData('text/plain', text); handled = true; };
        document.addEventListener('copy', onCopy, { capture: true });
        try { copied = document.execCommand('copy') && handled; } finally { document.removeEventListener('copy', onCopy, { capture: true }); }
      }
      if (!copied) throw new Error('未能复制，请使用 ⌘ / Ctrl + C。');
      if (captured !== clip) return;
      copyControl.replaceChildren(__shijuNoteIcon('check')); copyStatus.textContent = '已复制'; clearTimeout(copyTimer);
      copyTimer = setTimeout(() => { copyControl.replaceChildren(__shijuNoteIcon('copy')); copyStatus.textContent = ''; }, 1400);
    } catch (error) { showToast(error.message); }
    finally { copyBusy = false; copyControl.disabled = busy; }
  }
  function place(node, rect) {
    const box = node.getBoundingClientRect();
    node.style.left = `${Math.max(8, Math.min(rect.left, innerWidth - box.width - 8))}px`;
    const below = rect.bottom + 8;
    node.style.top = `${Math.max(8, Math.min(below, innerHeight - box.height - 8))}px`;
  }
  function visibleSelectionRect() {
    if (!captured || !capturedRange?.startContainer.isConnected || !capturedRange.endContainer.isConnected || capturedRange.toString().trim() !== captured.text.trim()) return null;
    const bounds = { left: 0, top: 0, right: innerWidth, bottom: innerHeight };
    const parents = new Set();
    for (const node of [capturedRange.startContainer, capturedRange.endContainer]) {
      for (let parent = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement; parent; parent = parent.parentElement) parents.add(parent);
    }
    for (const parent of parents) {
      if (parent === document.body || parent === document.documentElement) continue;
      const style = getComputedStyle(parent), rect = parent.getBoundingClientRect();
      if (/(auto|scroll|hidden|clip)/.test(style.overflowX)) { bounds.left = Math.max(bounds.left, rect.left); bounds.right = Math.min(bounds.right, rect.right); }
      if (/(auto|scroll|hidden|clip)/.test(style.overflowY)) { bounds.top = Math.max(bounds.top, rect.top); bounds.bottom = Math.min(bounds.bottom, rect.bottom); }
    }
    const rect = [...capturedRange.getClientRects()].findLast(rect => rect.width > 0 && rect.height > 0 && rect.right > bounds.left && rect.left < bounds.right && rect.bottom > bounds.top && rect.top < bounds.bottom);
    return rect && { left: Math.max(bounds.left, rect.left), right: Math.min(bounds.right, rect.right), top: Math.max(bounds.top, rect.top), bottom: Math.min(bounds.bottom, rect.bottom) };
  }
  function positionSelectionTools() {
    if (toolsFrame || !bar || bar.hidden || busy) return;
    toolsFrame = requestAnimationFrame(() => {
      toolsFrame = null; if (bar.hidden || busy) return;
      const rect = visibleSelectionRect();
      if (!rect) { hideBar(); captured = null; capturedRange = null; return; }
      place(bar, rect); positionColorPalette();
    });
  }
  function showToast(text, url) {
    mount(); const node = shadow.querySelector('.toast'); node.replaceChildren();
    const p = document.createElement('p'); p.textContent = text; node.append(p);
    if (url && /^https:\/\/(?:[\w-]+\.)*(?:yuque\.com|feishu\.cn)\//.test(url)) { const link = document.createElement('a'); link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '查看'; p.append(link); }
    const pane = pageNotes?.bounds;
    node.style.right = pane && innerWidth >= 760 ? `${innerWidth - pane.left + 12}px` : '18px';
    node.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { node.hidden = true; }, 7000);
  }
  function selection() {
    const selected = window.getSelection();
    if (!selected?.rangeCount || selected.isCollapsed || !selected.toString().trim()) return null;
    const node = selected.anchorNode?.parentElement;
    if (node?.closest('input,textarea,[contenteditable]:not([contenteditable="false"]),shiju-clipper')) return null;
    return { text: selected.toString(), range: selected.getRangeAt(0).cloneRange() };
  }
  function updateSaveState() {
    const saved = annotations.some(item => item.id === noteItem?.id);
    noteSave.disabled = noteBusy || (!saved && !noteText.value.trim());
    noteSave.textContent = noteBusy ? '保存中…' : '保存';
    noteText.disabled = noteBusy; noteCancel.disabled = noteBusy;
    editor.setAttribute('aria-busy', String(noteBusy));
  }
  function hideToast() { clearTimeout(toastTimer); if (shadow) shadow.querySelector('.toast').hidden = true; }
  function openNote(item, range) {
    mount(); if (noteBusy) return;
    if (noteItem && !editor.hidden) {
      if (noteItem.id === item.id) { pageNotes.open(); pageNotes.alignEditor(range?.getBoundingClientRect().top); noteText.focus({ preventScroll: true }); return; }
      if (noteText.value !== noteItem.clip.note) { noteError.textContent = '请先保存或取消当前笔记。'; pageNotes.open(); return; }
    }
    noteItem = structuredClone(item); noteRange = range?.cloneRange(); noteText.value = item.clip.note; noteError.textContent = '';
    updateSaveState(); hideToast();
    hideBar(); selectedNoteId = item.id; renderPageNotes();
    pageNotes.edit(item, range?.getBoundingClientRect().top); paintDraft();
    window.getSelection()?.removeAllRanges(); noteText.focus({ preventScroll: true });
  }
  function closeNoteEditor(force = false) {
    if (noteBusy && !force) return;
    const focusId = noteItem?.id; noteItem = null; noteRange = null;
    if (selectedNoteId === focusId && !annotations.some(item => item.id === focusId)) selectedNoteId = null;
    CSS.highlights?.delete('shiju-draft');
    pageNotes?.endEdit(focusId);
  }
  function collapseNotes() {
    deleteConfirm?.close();
    if (noteItem && !noteItem.clip.note.trim() && !noteText.value.trim()) closeNoteEditor();
  }
  function paintDraft(index) {
    if (!CSS.highlights || !globalThis.Highlight) return;
    CSS.highlights.delete('shiju-draft');
    if (!noteItem || editor.hidden) return;
    try {
      index ||= anchors.indexText();
      const match = anchors.resolveAnchor(index.text, noteItem.anchor);
      noteRange = match && anchors.rangeAt(index, match.start, match.end);
      if (noteRange) { const highlight = new Highlight(noteRange); highlight.priority = 20; CSS.highlights.set('shiju-draft', highlight); }
    } catch { noteRange = null; }
  }
  function renderPageNotes() {
    if (!host && !annotations.length) return;
    mount();
    const ordered = [...annotations].sort((a, b) => {
      const first = liveRanges.get(a.id); const second = liveRanges.get(b.id);
      if (first && second) return first.compareBoundaryPoints(Range.START_TO_START, second);
      if (first || second) return first ? -1 : 1;
      return a.anchor.start - b.anchor.start;
    });
    pageNotes.render(ordered.map(item => ({ ...item, located: liveRanges.has(item.id) })), selectedNoteId);
  }
  function locateNote(id) {
    const range = liveRanges.get(id);
    if (!range?.startContainer.isConnected) { showToast('原文位置已变化，笔记仍保留在侧栏中。'); return; }
    selectedNoteId = id;
    hideBar();
    window.getSelection()?.removeAllRanges();
    range.startContainer.parentElement?.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    if (CSS.highlights && globalThis.Highlight) {
      const focus = new Highlight(range); focus.priority = 10; CSS.highlights.set('shiju-focus', focus);
      clearTimeout(focusTimer); focusTimer = setTimeout(() => CSS.highlights.delete('shiju-focus'), 1800);
    }
    renderPageNotes(); pageNotes.open(id, range.getBoundingClientRect().top);
  }
  function viewNote(item, range) {
    mount();
    if (noteItem && noteText.value !== noteItem.clip.note && noteItem.id !== item.id) { noteError.textContent = '请先保存或取消当前笔记。'; pageNotes.open(); return; }
    if (noteItem?.id === item.id) { pageNotes.open(item.id, range?.getBoundingClientRect().top); return; }
    if (noteItem) closeNoteEditor();
    selectedNoteId = item.id; hideBar(); hideToast();
    if (CSS.highlights && globalThis.Highlight && range) { const focus = new Highlight(range); focus.priority = 10; CSS.highlights.set('shiju-focus', focus); }
    renderPageNotes(); pageNotes.open(item.id, range?.getBoundingClientRect().top);
  }
  function editSidebarNote(id) {
    const item = annotations.find(note => note.id === id);
    if (!item) return;
    openNote(item, liveRanges.get(id));
  }
  async function deleteSidebarNote(id, { anchor, bounds } = {}) {
    const item = annotations.find(note => note.id === id);
    if (!item || noteBusy) return;
    if (!await deleteConfirm.ask(anchor, { bounds })) return;
    if (noteBusy || !annotations.some(note => note.id === id)) return;
    noteBusy = true;
    try {
      await request('ANNOTATION_DELETE', { id });
      if (noteItem?.id === id) closeNoteEditor(true);
      if (selectedNoteId === id) selectedNoteId = null;
      await refreshAnnotations(); hideToast();
    } catch (error) { showToast(error.message); }
    finally { noteBusy = false; }
  }
  async function annotate(withNote, color) {
    if (busy || !captured || !capturedRange) return;
    try {
      if (!CSS.highlights || !globalThis.Highlight) throw new Error('当前浏览器不支持网页高亮，请更新浏览器；仍可使用剪藏。');
      const range = capturedRange;
      const index = anchors.indexText();
      const anchor = anchors.anchorRange(range, index);
      const normalizedRange = anchors.rangeAt(index, anchor.start, anchor.end);
      const existing = annotations.find(item => { const old = liveRanges.get(item.id); return old && old.compareBoundaryPoints(Range.START_TO_START, normalizedRange) === 0 && old.compareBoundaryPoints(Range.END_TO_END, normalizedRange) === 0; });
      const nextColor = color === undefined ? existing?.color || activeColor : colorTools.normalize(color);
      const item = existing ? { ...existing, color: nextColor } : { id: newId(), clip: { ...captured, kind: undefined, document: undefined }, anchor, color: nextColor };
      if (withNote) { openNote(item, range); return; }
      if (!existing || existing.color !== nextColor) {
        busy = true; setMarkerBusy(true);
        await request('ANNOTATION_UPSERT', { annotation: item });
        await refreshAnnotations();
      }
      clearTimeout(focusTimer); CSS.highlights?.delete('shiju-focus');
      activeColor = nextColor; syncColorControls();
      window.getSelection()?.removeAllRanges(); hideBar(); hideToast();
    } catch (error) { showToast(error.message); }
    finally { busy = false; setMarkerBusy(false); }
  }
  async function saveAnnotation() {
    if (!noteItem || noteBusy || noteSave.disabled) return null;
    const sourceKey = keyFor(location.href);
    noteBusy = true; noteError.textContent = ''; updateSaveState();
    try {
      const item = await request('ANNOTATION_UPSERT', { annotation: { ...noteItem, clip: { ...noteItem.clip, note: noteText.value } } });
      if (keyFor(location.href) !== sourceKey) return item;
      await refreshAnnotations(); closeNoteEditor(true); window.getSelection()?.removeAllRanges(); selectedNoteId = item.id; renderPageNotes(); pageNotes.open(item.id, liveRanges.get(item.id)?.getBoundingClientRect().top);
      hideToast();
      return item;
    } catch (error) { if (keyFor(location.href) === sourceKey) noteError.textContent = error.message; return null; }
    finally { noteBusy = false; updateSaveState(); }
  }
  function paintAnnotations() {
    liveRanges = new Map();
    if (!CSS.highlights || !globalThis.Highlight) { renderPageNotes(); return; }
    for (const color of Object.keys(colors)) CSS.highlights.delete(`shiju-${color}`);
    for (const name of customHighlights) CSS.highlights.delete(name); customHighlights.clear();
    pointer.clear();
    if (!annotations.length) { if (customStyle) { customStyle.replaceSync(''); customRules = ''; } CSS.highlights.delete('shiju-focus'); paintDraft(); renderPageNotes(); return; }
    let index;
    try { index = anchors.indexText(); } catch { renderPageNotes(); return; }
    const grouped = {};
    for (const item of annotations) {
      if (!colorTools.valid(item.color)) continue;
      const match = anchors.resolveAnchor(index.text, item.anchor);
      const range = match && anchors.rangeAt(index, match.start, match.end);
      if (range && range.toString() === item.anchor.exact) { liveRanges.set(item.id, range); (grouped[item.color] ||= []).push(range); }
    }
    const rules = [];
    for (const [color, ranges] of Object.entries(grouped)) {
      if (!colorTools.valid(color)) continue;
      const name = colors[color] ? `shiju-${color}` : `shiju-custom-${color.slice(1).toLowerCase()}`;
      CSS.highlights.set(name, new Highlight(...ranges));
      if (!colors[color]) { customHighlights.add(name); rules.push(`::highlight(${name}){background-color:${colorTools.hex(color)};color:${colorTools.ink(color)}}`); }
    }
    if (rules.length && !customStyle) customStyle = new CSSStyleSheet();
    if (customStyle && !document.adoptedStyleSheets.includes(customStyle)) document.adoptedStyleSheets = [...document.adoptedStyleSheets, customStyle];
    if (customStyle && customRules !== rules.join('\n')) { customRules = rules.join('\n'); customStyle.replaceSync(customRules); }
    paintDraft(index);
    if (selectedNoteId && !liveRanges.has(selectedNoteId)) CSS.highlights.delete('shiju-focus');
    renderPageNotes();
  }
  async function refreshAnnotations() {
    const version = ++refreshVersion;
    try {
      const data = await request('ANNOTATIONS_LIST'); if (version !== refreshVersion) return;
      annotations = data; paintAnnotations();
      if (!pageNotesInitialized) { pageNotesInitialized = true; if (annotations.some(item => item.clip.note.trim())) pageNotes?.open(); }
    }
    catch {}
  }
  function routeChanged() {
    if (lastUrl === location.href) return;
    clearTimeout(renderTimer); clearTimeout(matchDeadline); renderTimer = null; matchDeadline = null; if (positionFrame) cancelAnimationFrame(positionFrame); positionFrame = null;
    pointer.clear(); hideBar(); lastUrl = location.href; captured = null; annotations = []; selectedNoteId = null; pageNotesInitialized = false; deleteConfirm?.close(); closeNoteEditor(true); pageNotes?.close(); paintAnnotations(); refreshAnnotations();
  }
  async function capture(target) {
    if (busy || !captured) return;
    if (captured.text.length > 30000) { showToast('选中文字超过 30,000 字符，请缩短选区。'); return; }
    hideColorPalette(); busy = true; bar?.querySelectorAll('button').forEach(control => { control.disabled = true; });
    try {
      const data = await request('CAPTURE', { clip: captured, target: target === 'edit' ? undefined : target, openPanel: true });
      if (data.needsReplace) showToast('新的剪藏等待处理，请在工作台选择替换或保留当前草稿。');
      else if (data.needsSetup) showToast('剪藏已保留，请在拾句的连接设置中配置目标平台。');
      else if (data.needsImageReview) showToast('图文已放入工作台，请检查图片后选择保存方式。');
      else if (target === 'edit') showToast('剪藏已放入工作台');
      else showToast(`已保存到${target === 'yuque' ? '语雀' : '飞书'}`, data.url);
      hideBar();
    } catch (error) { showToast(error.message); }
    finally { busy = false; bar?.querySelectorAll('button').forEach(control => { control.disabled = false; }); refreshConfig(); }
  }
  function inspectSelection() {
    routeChanged();
    if (busy || editor && !editor.hidden && pageNotes?.isOpen) return;
    const current = selection();
    if (!current) { captured = null; capturedRange = null; if (bar) hideBar(); return; }
    capturedRange = current.range;
    captured = { id: newId(), title: (document.title || '网页摘录').slice(0, 120), sourceTitle: document.title.slice(0, 500), sourceUrl: location.href, text: current.text, capturedAt: new Date().toISOString(), note: '', prompt: '', analysis: '' };
    try { const document = globalThis.__shijuArticleExtractor?.selectionDocument(current.range); if (document) captured = { ...captured, kind: 'selection', document }; } catch { /* Plain text remains available if a complex selection cannot be structured. */ }
    if (!config.toolbar) { if (bar) hideBar(); return; }
    mount(); hideToolbarTip(); hideColorPalette(); resetCopyFeedback();
    if (annotations.length) { try { const index = anchors.indexText(), anchor = anchors.anchorRange(current.range, index), normalized = anchors.rangeAt(index, anchor.start, anchor.end); const existing = annotations.find(item => { const range = liveRanges.get(item.id); return range && range.compareBoundaryPoints(Range.START_TO_START, normalized) === 0 && range.compareBoundaryPoints(Range.END_TO_END, normalized) === 0; }); if (existing) activeColor = existing.color; } catch {} }
    syncColorControls(); bar.hidden = false;
    const rect = Array.from(current.range.getClientRects()).at(-1) || current.range.getBoundingClientRect(); place(bar, rect);
  }
  document.addEventListener('pointerdown', event => {
    if (event.composedPath().includes(host)) return;
    clearTimeout(selectionTimer); selectionTimer = null;
    if (!busy) { hideBar(); captured = null; capturedRange = null; }
  }, { passive: true });
  document.addEventListener('pointerup', event => {
    if (event.composedPath().includes(host)) return;
    clearTimeout(selectionTimer); selectionTimer = setTimeout(inspectSelection, 40);
  });
  document.addEventListener('click', event => {
    if (event.composedPath().includes(host) || selection() || noteBusy) return;
    const caret = document.caretRangeFromPoint(event.clientX, event.clientY);
    if (!caret) return;
    const clickable = noteItem ? [noteItem, ...annotations.filter(item => item.id !== noteItem.id)] : annotations;
    for (const item of clickable) {
      const range = item.id === noteItem?.id ? noteRange : liveRanges.get(item.id);
      if (!range?.startContainer.isConnected) continue;
      const rectHit = Array.from(range.getClientRects()).some(rect => event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom);
      if (!rectHit || !range.isPointInRange(caret.startContainer, caret.startOffset)) continue;
      if (!item.clip.note.trim() && item.id !== noteItem?.id) {
        clearTimeout(selectionTimer); selectionTimer = null;
        mount(); resetCopyFeedback(); captured = structuredClone(item.clip); capturedRange = range.cloneRange(); activeColor = item.color; syncColorControls(); hideColorPalette(); hideToolbarTip(); if (config.toolbar) { bar.hidden = false; place(bar, range.getBoundingClientRect()); }
      } else { event.preventDefault(); viewNote(item, range); }
      break;
    }
  });
  document.addEventListener('keyup', event => {
    if (event.key === 'Escape') { if (paletteEscape) { paletteEscape = false; return; } if (finishCustomPicker()) return; if (bar) hideBar(); closeNoteEditor(); return; }
    if (!event.composedPath().includes(host) && event.shiftKey) inspectSelection();
  });
  function alignActiveEditor() {
    if (positionFrame || !pageNotes?.isOpen || (!noteItem && !selectedNoteId)) return;
    positionFrame = requestAnimationFrame(() => { positionFrame = null; const range = noteItem ? noteRange : liveRanges.get(selectedNoteId); if (range?.startContainer.isConnected) pageNotes.alignCurrent(range.getBoundingClientRect().top); });
  }
  document.addEventListener('scroll', event => {
    if (event.composedPath().includes(host)) return;
    pointer.clear();
    positionSelectionTools(); alignActiveEditor();
  }, { passive: true, capture: true });
  window.addEventListener('resize', () => { pointer.clear(); positionSelectionTools(); alignActiveEditor(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { routeChanged(); refreshConfig(); refreshAnnotations(); } });
  window.addEventListener('popstate', routeChanged); window.addEventListener('hashchange', routeChanged);
  const observer = new MutationObserver(records => {
    routeChanged();
    const outside = records.filter(record => !(record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement)?.closest('shiju-clipper'));
    if (outside.length) positionSelectionTools();
    if ((!annotations.length && !noteItem) || !outside.some(record => record.type !== 'attributes')) return;
    const rematch = () => { clearTimeout(renderTimer); clearTimeout(matchDeadline); renderTimer = null; matchDeadline = null; paintAnnotations(); };
    clearTimeout(renderTimer); renderTimer = setTimeout(rematch, 250); if (!matchDeadline) matchDeadline = setTimeout(rematch, 1000);
  });
  observer.observe(document.body || document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['style', 'class', 'hidden'] });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (message.type === 'PUBLIC_SETTINGS_CHANGED') { applyConfig(message.settings); respond({ ok: true }); }
    if (message.type === 'ANNOTATIONS_CHANGED') { if (message.pageKey === keyFor(location.href)) refreshAnnotations(); respond({ ok: true }); }
    if (message.type === 'CAPTURE_SELECTION') {
      if (!document.hasFocus() || document.activeElement?.tagName === 'IFRAME') { respond({ ok: false }); return; }
      inspectSelection(); if (captured) capture('edit'); respond({ ok: Boolean(captured) });
    }
  });
  refreshAnnotations();
})();
