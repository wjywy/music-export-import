(() => {
  globalThis.__shijuCreateNotesSidebar = ({ shadow, editor, onLocate, onEdit, onDelete, onCollapse, getSourceTop = () => null }) => {
    const make = (tag, text = '', cls = '') => { const node = document.createElement(tag); node.textContent = text; if (cls) node.className = cls; return node; };
    const button = (label, callback) => { const node = make('button'); node.type = 'button'; node.setAttribute('aria-label', label); node.title = label; node.addEventListener('click', callback); return node; };
    const style = make('style');
    style.textContent = `
.page-notes{position:fixed;right:0;top:0;bottom:0;width:376px;max-width:100vw;display:flex;flex-direction:column;background:#fff;color:#303632;border-left:1px solid #f0f1ef;overflow:hidden;z-index:1}
.page-notes-header{height:56px;min-height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 24px;background:#fff}.page-notes-header strong{font-size:14px;font-weight:550;color:#525b55}.page-notes-header button{width:32px;min-height:32px;padding:4px;color:#929b95;font-size:22px;margin-right:-8px}
.page-notes-list{display:flex;flex-direction:column;align-items:stretch;min-height:0;overflow:auto;overscroll-behavior:contain;flex:1;padding:16px 18px 32px;scrollbar-width:thin;overflow-anchor:none}
.page-note{flex-shrink:0;padding:24px;background:#fff;border:1px solid #eceeec;border-radius:8px;margin-bottom:16px}.page-note.selected{border-color:#e5e9e5}.page-note.editing{padding:0;border:0}.page-note:focus-visible{outline:2px solid #708679;outline-offset:2px}
.page-note-top{display:flex;align-items:flex-start;gap:12px}.page-note-avatar{display:flex;align-items:center;justify-content:center;width:28px;height:28px;flex-shrink:0;border-radius:50%;background:#f2f3f0;color:#97a097}.page-note-avatar svg{width:17px;height:17px}.page-note-author{min-width:0;flex:1}.page-note-name{display:block;font-size:13px;line-height:1.6;font-weight:500;color:#626b65}.page-note-top time{display:block;font-size:11px;line-height:1.8;color:#8d958f;margin-top:2px;font-variant-numeric:tabular-nums}
.page-note-body{font-size:14px;line-height:1.9;white-space:pre-wrap;overflow-wrap:anywhere;margin:18px 0 14px 40px;color:#343c36;user-select:text;cursor:text}.page-note-actions{display:flex;gap:8px;margin-left:34px}.page-note-actions button{display:inline-flex;align-items:center;justify-content:center;padding:6px;width:32px;min-height:32px;color:#919b93;border-radius:5px}.page-note-actions button:hover{background:#f5f6f4;color:#4e5c52}.page-note-actions .delete:hover{color:#a33d36;background:#fbf2ef}.page-note-lost{font-size:11px;line-height:1.7;color:#8b6d3b;margin:10px 0 0 40px}.page-notes-empty{font-size:12px;line-height:1.9;color:#929b94;margin:22px 8px}
.page-notes .notebook{position:static;width:100%;max-width:none;max-height:none;overflow:visible;box-shadow:0 4px 20px #22302712,0 1px 4px #22302708;border:1px solid #f1f2ef;border-radius:6px;padding:20px;background:#fff}.page-notes .notebook textarea{display:block;width:100%;min-height:152px;max-height:320px;resize:vertical;font-size:14px;line-height:1.85;padding:12px;border:1px solid #e1e5e1;border-radius:5px;color:#343c36;background:#fff}.page-notes .notebook textarea::placeholder{color:#a2a9a3}.page-notes .notebook textarea:focus{border-color:#9baea0;box-shadow:0 0 0 1px #9baea018}.page-notes .notebook textarea:focus-visible{outline:1px solid #9baea0;outline-offset:-1px}.page-notes .notebook textarea:disabled{opacity:.75;background:#fcfcfb}
.page-notes .note-actions{justify-content:flex-start;gap:12px;position:sticky;bottom:0;background:#fff;margin-top:12px;padding:0;z-index:1;flex-wrap:wrap}.page-notes .note-actions button{font-size:13px;padding:6px 16px;min-height:34px;min-width:64px;line-height:1.5;border-radius:5px}.page-notes .note-actions .primary{border:1px solid #285942}.page-notes .note-actions .primary:disabled{background:#c1dfcc;border-color:#c1dfcc;color:#fff}.page-notes .note-actions .cancel{border:1px solid #e2e5e1;background:#fff;color:#626b65}.page-note-draft{flex-shrink:0;margin-bottom:16px}.note-error{margin:10px 0 0;color:#a33d36;font-size:12px;line-height:1.7;overflow-wrap:anywhere}.note-error:empty{display:none}
.page-notes-dock{position:fixed;right:0;top:40%;width:52px;height:52px;z-index:2;pointer-events:none;clip-path:inset(-20px 0 -20px -20px)}.page-notes-dock.is-peeking{pointer-events:auto}.page-notes-trigger{cursor:grab;position:absolute;pointer-events:auto;right:8px;top:4px;display:flex;align-items:center;justify-content:center;width:44px;min-height:44px;height:44px;padding:0;border:1px solid #e1e6df;border-radius:50%;background:#fff;box-shadow:0 3px 14px #263c2b12;color:#657c6b;transform:translateX(30px);transition:transform 160ms cubic-bezier(.2,.8,.2,1)}.page-notes-trigger svg{display:block;width:21px;height:21px;transform:translateX(-7px);transition:transform 160ms cubic-bezier(.2,.8,.2,1)}.page-notes-trigger:hover{background:#fff}.page-notes-dock.is-peeking .page-notes-trigger,.page-notes-dock:focus-within .page-notes-trigger,.page-notes-dock[data-mode=full] .page-notes-trigger{transform:none}.page-notes-dock.is-peeking svg,.page-notes-dock:focus-within svg,.page-notes-dock[data-mode=full] svg{transform:none}.page-notes-dock.is-peeking .page-notes-trigger,.page-notes-dock.is-peeking svg{transition-duration:280ms}.page-notes-dock:focus-within .page-notes-trigger,.page-notes-dock:focus-within svg{transition:none}.page-notes-dock .page-notes-trigger:active{transform:translateX(0) scale(.96)}.page-notes-dock[data-reduce=true] .page-notes-trigger,.page-notes-dock[data-reduce=true] svg{transition:none}.page-notes-dock[data-reduce=true] .page-notes-trigger:active{transform:none}
.bar{z-index:4}.toast{z-index:5;pointer-events:none}.toast a{pointer-events:auto}@media(max-width:600px){.page-notes{width:320px}.page-note{padding:20px}.page-note-body,.page-note-lost{margin-left:0}.page-note-actions{margin-left:-6px}.page-notes .notebook{padding:16px}.page-notes-list{padding:12px 14px 28px}.page-notes-header{padding:0 20px}.page-notes .notebook textarea{min-height:136px}}@media(hover:none){.page-notes-dock .page-notes-trigger,.page-notes-dock svg{transform:none}}@media(prefers-reduced-motion:reduce){.page-notes-trigger,.page-notes-trigger svg{transition:none}.page-notes-dock .page-notes-trigger:active{transform:none}}
`;
    const rail = make('aside', '', 'page-notes'); rail.hidden = true; rail.setAttribute('aria-label', '本页笔记侧栏'); rail.id = `shiju-notes-${crypto.randomUUID()}`;
    const header = make('div', '', 'page-notes-header'), close = button('收起本页笔记', event => { setOpen(false); onCollapse?.(); if (event.detail === 0 && !dock.hidden) trigger.focus({ preventScroll: true }); }); close.textContent = '×'; header.append(make('strong', '笔记'), close);
    const list = make('div', '', 'page-notes-list'), empty = make('p', '选中一段文字，写下你的想法。', 'page-notes-empty'), parking = make('div'); parking.hidden = true; parking.append(editor); rail.append(header, list, parking);
    const draft = make('article', '', 'page-note-draft'), dock = make('div', '', 'page-notes-dock');
    const trigger = button('展开本页笔记', () => { if (isOpen) return; setOpen(true); alignCurrent(); if (editingItem) editor.querySelector('textarea').focus({ preventScroll: true }); else close.focus({ preventScroll: true }); }); trigger.className = 'page-notes-trigger'; trigger.append(__shijuNoteIcon('feather')); trigger.setAttribute('aria-controls', rail.id); trigger.setAttribute('aria-expanded', 'false'); dock.append(trigger); shadow.append(style, rail, dock);
    let items = [], isOpen = false, editingItem = null, selectedId = null, preferences = { ball: true, ballMode: 'edge', motion: 'system' }, parkTimer, alignFrame, interacting = 0;
    const records = new Map();
    function cancelPark() { clearTimeout(parkTimer); }
    function park() { cancelPark(); parkTimer = setTimeout(() => { if (!dock.matches(':focus-within')) dock.classList.remove('is-peeking'); }, 150); }
    trigger.addEventListener('pointerenter', () => { cancelPark(); dock.classList.add('is-peeking'); }); dock.addEventListener('pointerenter', cancelPark); dock.addEventListener('pointerleave', park); dock.addEventListener('focusin', cancelPark); dock.addEventListener('focusout', park);
    function setOpen(value) { cancelPark(); isOpen = value; rail.hidden = !value; dock.hidden = value || preferences.ball === false; if (value) dock.classList.remove('is-peeking'); trigger.setAttribute('aria-expanded', String(value)); }
    function formatTime(value) { const date = new Date(value), now = new Date(); return `${date.toDateString() === now.toDateString() ? '今天' : date.toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric', ...(date.getFullYear() !== now.getFullYear() ? { year: 'numeric' } : {}) })} ${date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false })}`; }
    function createCard(id) {
      const card = make('article', '', 'page-note'); card.dataset.noteId = id; card.tabIndex = 0; card.setAttribute('aria-label', '定位笔记原文');
      const top = make('div', '', 'page-note-top'), avatar = make('span', '', 'page-note-avatar'); avatar.setAttribute('aria-hidden', 'true'); avatar.append(__shijuNoteIcon('person'));
      const author = make('div', '', 'page-note-author'), time = make('time'); author.append(make('span', '我', 'page-note-name'), time); top.append(avatar, author);
      const summary = make('div'), body = make('p', '', 'page-note-body'), lost = make('p', '原文位置已变化，笔记已为你保留。', 'page-note-lost'), actions = make('div', '', 'page-note-actions');
      const edit = button('编辑笔记', () => onEdit(id)), remove = button('删除笔记', async () => { interacting++; try { await onDelete(id, { anchor: remove, bounds: () => rail.getBoundingClientRect() }); } finally { interacting--; } }); edit.append(__shijuNoteIcon('edit')); remove.className = 'delete'; remove.append(__shijuNoteIcon('trash')); actions.append(edit, remove); summary.append(body, lost, actions); card.append(top, summary);
      card.onclick = event => { if (event.target.closest('button,a') || body.contains(event.target) || getSelection()?.toString() || shadow.getSelection?.()?.toString()) return; if (!lost.hidden) return; onLocate(id); };
      card.onkeydown = event => { if (event.target === card && ['Enter', ' '].includes(event.key)) { event.preventDefault(); if (lost.hidden) onLocate(id); } };
      return { card, top, time, summary, body, lost, edit, remove };
    }
    function sync() {
      const previousTop = list.scrollTop;
      const desired = items.map((item, index) => {
        if (!records.has(item.id)) records.set(item.id, createCard(item.id)); const record = records.get(item.id), editing = editingItem?.id === item.id;
        record.card.classList.toggle('selected', item.id === selectedId); record.card.classList.toggle('editing', editing); record.card.tabIndex = editing ? -1 : 0; record.top.hidden = editing; record.summary.hidden = editing;
        record.time.dateTime = item.updatedAt; record.time.textContent = formatTime(item.updatedAt); record.time.title = new Date(item.updatedAt).toLocaleString('zh-CN');
        if (record.body.textContent !== item.clip.note) record.body.textContent = item.clip.note; record.lost.hidden = item.located;
        record.edit.setAttribute('aria-label', `编辑第 ${index + 1} 条笔记`); record.remove.setAttribute('aria-label', `删除第 ${index + 1} 条笔记`); return record.card;
      });
      const savedEditing = items.some(item => item.id === editingItem?.id);
      if (editingItem && !savedEditing) { let index = items.findIndex(item => item.anchor.start > editingItem.anchor.start); if (index < 0) index = desired.length; desired.splice(index, 0, draft); }
      const target = editingItem ? savedEditing ? records.get(editingItem.id).card : draft : parking;
      if (editor.parentElement !== target) target.append(editor); editor.hidden = !editingItem;
      if (!desired.length) desired.push(empty); const keep = new Set(desired);
      for (const child of [...list.children]) if (!keep.has(child)) child.remove(); desired.forEach((node, index) => { if (list.children[index] !== node) list.insertBefore(node, list.children[index] || null); });
      const ids = new Set(items.map(item => item.id)); for (const id of records.keys()) if (!ids.has(id)) records.delete(id);
      list.scrollTop = previousTop; setOpen(isOpen); alignCurrent();
    }
    function align(target, sourceTop) {
      if (!target || !isOpen) return;
      list.style.paddingBottom = '32px'; for (const child of list.children) child.style.marginTop = '';
      if (!Number.isFinite(sourceTop)) { target.scrollIntoView({ block: 'nearest', behavior: 'instant' }); return; }
      const area = list.getBoundingClientRect(); let cursor = area.top + parseFloat(getComputedStyle(list).paddingTop);
      for (const child of list.children) { const id = child === draft ? editingItem?.id : child.dataset.noteId, top = child === target ? sourceTop : getSourceTop(id), gap = Number.isFinite(top) ? Math.max(0, top - cursor) : 0; child.style.marginTop = `${gap}px`; cursor += gap + child.getBoundingClientRect().height + 16; }
      const box = target.getBoundingClientRect(), desired = Math.max(area.top + 12, Math.min(sourceTop, area.bottom - Math.min(box.height, area.height - 24) - 12)), natural = box.top + list.scrollTop, next = Math.max(0, natural - desired), extra = next - (list.scrollHeight - list.clientHeight);
      if (extra > 0) list.style.paddingBottom = `${32 + extra}px`; list.scrollTop = next;
    }
    function alignCurrent(sourceTop) { if (interacting || !isOpen) return; const id = editingItem?.id || selectedId, target = editingItem ? editor.parentElement : records.get(id)?.card; if (!target) return; align(target, Number.isFinite(sourceTop) ? sourceTop : getSourceTop(id)); }
    const resize = new ResizeObserver(() => { if (alignFrame || !isOpen) return; alignFrame = requestAnimationFrame(() => { alignFrame = null; alignCurrent(); }); }); resize.observe(editor);
    return {
      render(next, selected) { items = next.filter(item => item.clip.note.trim()); selectedId = selected; sync(); },
      edit(item, sourceTop) { editingItem = item; selectedId = item.id; setOpen(true); sync(); alignCurrent(sourceTop); },
      endEdit(focusId) { editingItem = null; list.style.paddingBottom = ''; for (const child of list.children) child.style.marginTop = ''; sync(); if (isOpen) (records.get(focusId)?.edit || close).focus({ preventScroll: true }); },
      alignEditor: alignCurrent, alignCurrent,
      open(id, sourceTop) { if (id) selectedId = id; setOpen(true); alignCurrent(sourceTop); },
      close() { setOpen(false); onCollapse?.(); },
      preferences(value) { preferences = value; dock.dataset.mode = value.ballMode || 'edge'; dock.dataset.reduce = String(value.motion === 'reduce'); setOpen(isOpen); },
      get isOpen() { return isOpen; }, get bounds() { return isOpen ? rail.getBoundingClientRect() : null; },
    };
  };
})();
