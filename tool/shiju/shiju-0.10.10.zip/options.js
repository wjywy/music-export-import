import { DEFAULT_SETTINGS, normalizeSettings, isConnected } from './lib/core.js';
import { createRepoSelect } from './lib/repo-select.js';
import { createChoiceSelect } from './lib/select.js';
import './lib/messaging.js';
const $ = id => document.getElementById(id), send = (type, payload = {}) => __shijuMessaging.send(type, payload);
const el = (tag, text = '', cls = '') => { const node = document.createElement(tag); node.textContent = text; node.className = cls; return node; };
let saved, drafts, modeSelect, picker, saving = new Set();
const groups = ['general', 'yuque', 'feishu'];
const general = value => ({ toolbar: value.toolbar !== false, ball: value.ball !== false });
const status = (message, error = false) => { $('status').textContent = message; $('status').classList.toggle('error', error); };
const groupStatus = (key, message, error = false) => { const node = $(`${key}-status`); node.textContent = message; node.classList.toggle('error', error); };
function button(text, action, cls = 'secondary') { const node = el('button', text, cls); node.type = 'button'; node.onclick = action; return node; }
function section(title, id) { const group = el('section', '', 'setting-group'); group.id = id; group.append(el('h2', title)); return group; }
function field(key, name, label, type = 'text', placeholder = '') {
  const wrap = el('div', '', 'field'), caption = el('label', label), input = el('input'); input.id = `${key}-${name}`; caption.htmlFor = input.id; input.type = type; input.value = drafts[key][name] || ''; input.placeholder = placeholder; input.autocomplete = 'off';
  input.oninput = () => { drafts[key][name] = input.value; if (key === 'yuque' && name === 'repo') { drafts.yuque.bookId = ''; drafts.yuque.repoName = ''; } groupStatus(key, '有未保存更改'); };
  wrap.append(caption, input); return wrap;
}
async function saveGroup(key, check = false) {
  if (saving.has(key)) return false;
  saving.add(key); const group = $(key === 'general' ? 'general' : key === 'yuque' ? 'targets' : 'feishu-settings'); group.inert = true; groupStatus(key, check ? '正在保存并检查连接…' : '正在保存…');
  try {
    const merged = normalizeSettings(key === 'general' ? { ...saved, ...drafts.general } : { ...saved, [key]: drafts[key] });
    const response = await send('SETTINGS', { group: key, values: key === 'general' ? general(merged) : merged[key] }); saved = response.settings; drafts[key] = key === 'general' ? general(saved) : structuredClone(saved[key]);
    if (key === 'yuque') { picker.setValue(saved.yuque); for (const name of ['repo','token']) { const input = $(`yuque-${name}`); if (input) input.value = drafts.yuque[name]; } $('yuque-repos-load').textContent = isConnected(saved, 'yuque') ? '重新连接语雀' : '连接语雀并选择知识库'; }
    if (check) { const result = await send('TEST_CONNECTION', { target: key }); groupStatus(key, result.message); }
    else groupStatus(key, '已保存');
    return true;
  } catch (error) { groupStatus(key, error.message, true); return false; }
  finally { saving.delete(key); group.inert = false; }
}
function toggle(label, hint, name) {
  const row = el('label', '', 'setting-row'), copy = el('span', '', 'copy'), input = el('input'); copy.append(el('strong', label), el('small', hint)); input.type = 'checkbox'; input.className = 'switch'; input.setAttribute('role', 'switch'); input.setAttribute('aria-label', label); input.checked = drafts.general[name];
  input.onchange = async () => { const previous = !input.checked; drafts.general[name] = input.checked; if (!await saveGroup('general')) { input.checked = previous; drafts.general[name] = previous; } }; row.append(copy, input); return row;
}
function render() {
  const root = $('settings-content'); root.replaceChildren();
  const reading = section('阅读与笔记', 'general');
  reading.append(toggle('划选后显示工具栏', '选中文字后，快速标记或保存。', 'toolbar'), toggle('网页笔记悬浮球', '从网页边缘展开本页笔记。', 'ball'));
  const generalStatus = el('p', '', 'connection-status'); generalStatus.id = 'general-status'; generalStatus.setAttribute('role', 'status'); reading.append(generalStatus);
  const yuque = section('语雀连接', 'targets');
  const line = el('div', '', 'connection-heading'), description = el('p', '登录语雀后，选择快捷保存使用的默认知识库。');
  const connect = button(isConnected(saved, 'yuque') ? '重新连接语雀' : '连接语雀并选择知识库', () => picker.open()); connect.id = 'yuque-repos-load'; line.append(description, connect);
  picker = createRepoSelect({ send, label: '默认知识库', onChoose: async repo => {
    drafts.yuque = { ...drafts.yuque, repo: repo.namespace, bookId: String(repo.id), repoName: repo.name };
    if (!await saveGroup('yuque')) throw new Error($('yuque-status').textContent);
  } }); picker.setValue(saved.yuque);
  const hint = el('small', '单次保存时可以更换知识库，不会修改这里的默认值。', 'field-hint');
  const yuqueStatus = el('p', isConnected(saved, 'yuque') ? '已配置默认知识库；登录状态以连接检查为准。' : '尚未连接语雀。', 'connection-status'); yuqueStatus.id = 'yuque-status'; yuqueStatus.setAttribute('role', 'status');
  const advancedYuque = el('details', '', 'advanced'); advancedYuque.id = 'yuque-advanced'; advancedYuque.append(el('summary', '高级连接设置'));
  advancedYuque.append(el('p', '连接遇到问题时，可手动填写知识库标识，或使用个人访问令牌。', 'field-hint'), field('yuque', 'repo', '知识库标识', 'text', '用户名/知识库，或完整知识库链接'), field('yuque', 'token', '个人访问令牌', 'password', '留空使用浏览器中的语雀登录态'));
  const yuqueActions = el('div', '', 'settings-actions'); yuqueActions.append(button('保存并检查连接', () => saveGroup('yuque', true), 'primary'), button('重新检查', async () => {
    if (saving.has('yuque')) return;
    saving.add('yuque'); groupStatus('yuque', '正在检查已保存连接…');
    try { const result = await send('TEST_CONNECTION', { target: 'yuque' }); groupStatus('yuque', result.message); } catch (error) { groupStatus('yuque', error.message, true); } finally { saving.delete('yuque'); }
  })); advancedYuque.append(yuqueActions);
  yuque.append(line, el('span','默认知识库','field-label default-repo-label'), picker.element, hint, yuqueStatus, advancedYuque);
  const optional = el('details', '', 'optional-settings'); optional.id = 'advanced'; optional.append(el('summary', '其他连接与高级设置'));
  const feishu = section('飞书连接（可选）', 'feishu-settings');
  feishu.append(el('p', '用于划词快捷保存与原文收藏导出。笔记卡片目前保存到语雀。', 'field-hint'), field('feishu', 'appId', 'App ID', 'text', 'cli_…'), field('feishu', 'appSecret', 'App Secret', 'password'));
  const modeRow = el('div', '', 'field'), modeLabel = el('span', '保存方式', 'field-label');
  modeSelect = createChoiceSelect({ label: '飞书保存方式', value: drafts.feishu.mode, options: [{ value: 'append', label: '追加到已有文档' }, { value: 'new', label: '新建到应用文件夹' }], onChange: value => { drafts.feishu.mode = value; $('feishu-document-field').hidden = value !== 'append'; $('feishu-folder-field').hidden = value !== 'new'; groupStatus('feishu', '有未保存更改'); } }); modeRow.append(modeLabel, modeSelect.element); feishu.append(modeRow);
  const documentField = field('feishu', 'documentUrl', '目标文档链接', 'url', 'https://你的工作区.feishu.cn/docx/…'); documentField.id = 'feishu-document-field'; documentField.hidden = drafts.feishu.mode !== 'append';
  const folderField = field('feishu', 'folderUrl', '应用创建的文件夹链接', 'url', 'https://你的工作区.feishu.cn/drive/folder/…'); folderField.id = 'feishu-folder-field'; folderField.hidden = drafts.feishu.mode !== 'new';
  const feishuStatus = el('p', '', 'connection-status'); feishuStatus.id = 'feishu-status'; feishuStatus.setAttribute('role', 'status');
  const help = el('details', '', 'advanced'); help.append(el('summary', '飞书配置说明'), el('p', '创建并发布企业自建应用，授予新版文档创建和编辑权限；保存图片还需要正文转换和图片上传权限。追加到已有文档时，需要为目标文档添加该应用并授予编辑权限。新建模式只支持该应用创建的文件夹。', 'field-hint'));
  feishu.append(documentField, folderField, button('保存并检查飞书连接', () => saveGroup('feishu', true), 'primary'), feishuStatus, help);
  const reset = el('details', '', 'advanced'); reset.append(el('summary', '重置阅读偏好'), el('p', '重新开启划选工具栏和网页悬浮球，不影响连接及本机内容。', 'field-hint'), button('重置这两项偏好', async () => { drafts.general = general(DEFAULT_SETTINGS); if (await saveGroup('general')) { picker.destroy(); modeSelect.destroy(); render(); groupStatus('general', '已恢复阅读偏好'); } }));
  optional.append(feishu, reset); root.append(reading, yuque, optional);
}
function navigate(value) {
  if (value?.provider === 'feishu') { $('advanced').open = true; $('feishu-settings').scrollIntoView({ block: 'start' }); }
  else $(value?.section === 'targets' ? 'targets' : 'general')?.scrollIntoView({ block: 'start' });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes.optionsNavigation) navigate(changes.optionsNavigation.newValue);
});
window.addEventListener('beforeunload', event => {
  if (drafts && groups.some(key => JSON.stringify(drafts[key]) !== JSON.stringify(key === 'general' ? general(saved) : saved[key]))) { event.preventDefault(); event.returnValue = ''; }
});
try {
  const initial = await send('OPTIONS_STATE'); saved = normalizeSettings(initial.settings); drafts = { general: general(saved), yuque: structuredClone(saved.yuque), feishu: structuredClone(saved.feishu) }; render();
  $('extension-version').textContent = `版本 ${chrome.runtime.getManifest().version}`;
  navigate(initial.navigation || { section: location.hash.slice(1) });
} catch (error) { status(error.message, true); }
