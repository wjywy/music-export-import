import { createChoiceSelect } from './lib/select.js';
import { imageNodes } from './lib/article-document.js';
import { imageSummary, ensureImagesForSave, blockReason } from './lib/image-access.js';
import { exportImageArchive } from './lib/image-export.js';
import { normalizeDocument, renderDocument, documentText } from './lib/article-document.js';
import { clipMarkdown, fingerprint, destinationKey, destinationLabel, isConnected, workbenchSettings, formatTime } from './lib/core.js';
import { createRepoSelect } from './lib/repo-select.js';

export function createOriginalsWorkspace({ send, root, footer, openSettings, isVisible, legacyBusy }) {
  const dom=document;
  const make=(tag,text='',cls='')=>{const el=dom.createElement(tag);el.textContent=text;el.className=cls;return el;};
  const button=(text,action,cls='')=>{const el=make('button',text,cls);el.type='button';el.onclick=action;return el;};
  const icon=(name,label,action)=>{const el=button('',action,'icon');el.setAttribute('aria-label',label);el.title=label;el.append(globalThis.__shijuNoteIcon(name));return el;};
  const confirmDelete=globalThis.__shijuCreateConfirmPopover(dom.body);
  const repoSelect=createRepoSelect({ send, onChoose: async repo => { const article=current(); if(!article||record)return; prefs.yuqueTargets={...(prefs.yuqueTargets||{}),[article.id]:{repo:repo.namespace,bookId:String(repo.id),repoName:repo.name}};await persistPrefs();drawFooter(); } });
  const params=new URLSearchParams(location.search);
  let articles=[],jobs=[],settings={},pending=null,captureState=null,prefs={},selectedId=null,record=null,active=false,query='',listScroll=0,positions={},navVersion=0,operation=null,operationId=null,searchTimer,positionTimer,noteTimer,patchQueue=Promise.resolve(),error='',renderEpoch=0,sourceTab=Number(params.get('sourceTab'))||null;
  const buffers=new Map();let targetPicker;let dismissedCaptureErrorId=null;let writing=0,renderedId=null,renderedBody='',knownRequest=null,requestNavigation=0,initial=true;
  const current=()=>record?.clip || articles.find(item=>item.id===selectedId);
  const sourceLabel=article=>{try{return new URL(article.sourceUrl).hostname;}catch{return '来源失效';}};
  const busy=()=>Boolean(operation||captureState?.status==='running'||legacyBusy());
  const toolbar=make('div','','original-toolbar'),search=make('input');search.type='search';search.id='original-search';search.placeholder='搜索原文…';search.setAttribute('aria-label','搜索原文');
  const back=button('‹ 返回列表',()=>showList(),'text-action'),actions=make('div','','original-actions');
  const capture=button('获取原文',()=>capturePage(),'capture-original');capture.id='capture-original';
  toolbar.append(search,back,actions,capture);
  const message=make('p','','error original-error');message.id='original-error';message.setAttribute('role','status');message.setAttribute('aria-live','polite');
  const update=make('section','','pending-capture original-update');update.id='original-update';const updateText=make('p'),updateActions=make('div','','form-actions');
  const accept=button('更新正文',()=>resolvePending(true),'primary compact'),keep=button('保留当前',()=>resolvePending(false),'secondary compact');updateActions.append(accept,keep);update.append(updateText,updateActions);
  const list=make('div','','original-list');list.id='original-list';
  const detail=make('div','','original-detail');detail.id='original-detail';
  const heading=make('h1'),meta=make('div','','original-meta'),body=make('article','','article-body'),notes=make('section','','article-personal');heading.tabIndex=-1;notes.setAttribute('aria-label','文章笔记');detail.append(heading,meta,body,notes);
  root.append(toolbar,message,update,list,detail);
  function showMessage() {
    const value=error || (captureState?.status==='error'&&captureState.id!==dismissedCaptureErrorId?captureState.error:'');message.textContent=value||'';message.hidden=!value;
    update.hidden=!pending;
    if(pending){const article=articles.find(item=>item.id===pending.articleId);updateText.textContent=selectedId===pending.articleId?'已提取过这篇文章。更新正文？':`《${article?.title||'原文'}》已在库中。更新正文？`;}
    capture.textContent=captureState?.status==='running'?'获取中…':'获取原文';capture.disabled=busy()||Boolean(pending);capture.setAttribute('aria-busy',String(captureState?.status==='running'));
    accept.disabled=keep.disabled=Boolean(operation||captureState?.status==='running');
    const remove=actions.querySelector('[aria-label="删除原文"]');if(remove)remove.disabled=busy()||Boolean(pending);
  }
  function remember() {
    if(!active)return;
    const main=dom.getElementById('main'),article=current();
    if(article&&!record){
      const top=main.getBoundingClientRect().top+toolbar.offsetHeight;
      const blocks=[...body.children,notes],index=blocks.findIndex(el=>el.getBoundingClientRect().bottom>top+1),rect=blocks[index]?.getBoundingClientRect();
      positions[article.id]={scroll:main.scrollTop,anchor:main.scrollTop>0&&rect&&rect.top<=top+1?{index,fraction:Math.max(0,(top-rect.top)/rect.height)}:null};
    }else if(!article)listScroll=main.scrollTop;
  }
  function restore() {
    const main=dom.getElementById('main'),article=current(),position=article?positions[article.id]:null;
    const target=position?.anchor&&[...body.children,notes][position.anchor.index];
    if(target){const rect=target.getBoundingClientRect();main.scrollTop+=rect.top-main.getBoundingClientRect().top-toolbar.offsetHeight+rect.height*position.anchor.fraction;}
    else main.scrollTop=article?position?.scroll||0:listScroll;
  }
  async function persistPrefs() {
    clearTimeout(positionTimer);const patch={selectedId:record?null:selectedId,query,listScroll,target:prefs.target||'yuque',yuqueTargets:prefs.yuqueTargets||{}};
    const article=current();if(article&&!record&&positions[article.id])patch.position={id:article.id,...positions[article.id]};
    try{prefs=await send('ORIGINAL_WORKSPACE',{patch});}catch(failure){error=failure.message;showMessage();}
  }
  function route() {
    if(!active)return;
    const url=new URL(location.href);url.hash='originals';
    if(record){url.searchParams.set('record',record.id);url.searchParams.delete('article');}
    else if(selectedId){url.searchParams.set('article',selectedId);url.searchParams.delete('record');}
    else {url.searchParams.delete('article');url.searchParams.delete('record');}
    if(sourceTab)url.searchParams.set('sourceTab',sourceTab);
    history.replaceState(null,'',url);
  }
  function renderList() {
    const fragment=dom.createDocumentFragment(),needle=query.trim().toLocaleLowerCase();
    const matches=[...articles].sort((a,b)=>Date.parse(b.capturedAt)-Date.parse(a.capturedAt)).filter(item=>(item.title+'\n'+item.sourceUrl+'\n'+item.text).toLocaleLowerCase().includes(needle));
    for(const article of matches){const row=button('',()=>showArticle(article.id),'original-row');row.dataset.originalId=article.id;row.append(make('h2',article.title),make('p',article.text.replace(/\s+/g,' '),'original-excerpt'),make('span',`${sourceLabel(article)} · ${new Date(article.capturedAt).toLocaleDateString('zh-CN',{month:'numeric',day:'numeric'})}`,'original-row-meta'));fragment.append(row);}
    if(!matches.length)fragment.append(make('p',articles.length?'没有找到匹配的原文。':'提取文章，留着慢慢读。','history-empty'));
    list.replaceChildren(fragment);
  }
  async function patchArticle(id,patch,expectedRevision) {
    writing++;
    const work=patchQueue.catch(()=>{}).then(()=>send('ORIGINAL_UPDATE',{id,patch,expectedRevision}));patchQueue=work;
    try{const item=await work;const index=articles.findIndex(value=>value.id===id);if(index>=0&&articles[index].revision<=item.revision)articles[index]=item;return item;}
    catch(failure){const buffer=buffers.get(id);if(buffer){if('noteDraft'in patch)buffer.notePending=true;}error=`个人内容未保留：${failure.message}`;showMessage();throw failure;}
    finally{writing--;}
  }
  async function flushInputs() {
    clearTimeout(noteTimer);
    const writes=[];
    for(const [id,buffer]of buffers){const patch={};if(buffer.notePending){patch.noteDraft=buffer.noteDraft;buffer.notePending=false;}if(Object.keys(patch).length)writes.push(patchArticle(id,patch));}
    await Promise.all(writes);await patchQueue;
  }
  function editNote(article) {
    let buffer=buffers.get(article.id)||{};buffer.noteDraft=article.noteDraft!==null?article.noteDraft:article.note;buffer.notePending=true;buffers.set(article.id,buffer);
    const position=dom.getElementById('main').scrollTop;drawNotes();drawFooter();dom.getElementById('main').scrollTop=position;notes.querySelector('textarea').focus();flushInputs().catch(()=>{});
  }
  function drawNotes() {
    const article=current();notes.replaceChildren();if(!article)return;
    if(record){if(article.note)notes.append(make('div','文章笔记','section-label'),make('p',article.note,'body-copy'));drawLegacyContent(article);return;}
    const buffer=buffers.get(article.id),draftValue=buffer&&'noteDraft'in buffer?buffer.noteDraft:article.noteDraft;
    if(draftValue!==null&&draftValue!==undefined){
      const input=make('textarea');input.rows=4;input.maxLength=20000;input.value=draftValue;input.placeholder='写下你的想法…';input.setAttribute('aria-label','文章笔记');
      input.oninput=()=>{const next=buffers.get(article.id)||{};next.noteDraft=input.value;next.notePending=true;buffers.set(article.id,next);clearTimeout(noteTimer);noteTimer=setTimeout(()=>flushInputs().catch(()=>{}),150);};
      const complete=async(cancel=false)=>{if(operation)return;operation='note';input.disabled=true;showMessage();drawFooter();try{await flushInputs();await patchArticle(article.id,cancel?{noteDraft:null}:{note:input.value,noteDraft:null});const next=buffers.get(article.id);if(next){delete next.noteDraft;delete next.notePending;}error='';drawNotes();}catch{}finally{operation=null;input.disabled=false;showMessage();drawFooter();}};
      const controls=make('div','','form-actions');controls.append(button('完成',()=>complete(false),'text-action'),button('取消',()=>complete(true),'text-action'));
      input.onkeydown=event=>{if(event.isComposing)return;if(event.key==='Escape'){event.preventDefault();complete(true);}if(event.key==='Enter'&&(event.metaKey||event.ctrlKey)){event.preventDefault();complete(false);}};
      notes.append(input,controls);
    }else if(article.note){const row=make('div','','note-preview-row');row.append(make('p',article.note),icon('edit','编辑文章笔记',()=>editNote(article)));notes.append(make('div','文章笔记','section-label'),row);}
    const extras=make('div','','extras');const add=button('＋ 添加文章笔记',()=>editNote(article));add.hidden=Boolean(article.note||draftValue!==null&&draftValue!==undefined);
    extras.append(add);notes.append(extras);drawLegacyContent(article);
    notes.inert=operation==='save';
  }
  function drawLegacyContent(article) {
    if(!article.prompt&&!article.analysis)return;
    const archive=make('details','','history-details');archive.append(make('summary','历史附加内容'));
    if(article.prompt)archive.append(make('p',article.prompt,'body-copy'));
    if(article.analysis)archive.append(make('p',article.analysis,'body-copy'));
    notes.append(archive);
  }
  function renderDetail(force=false) {
    const article=current();if(!article)return;
    const key=record?'record:'+record.id:article.id,nextBody=JSON.stringify(article.document);
    if(force||renderedId!==key||renderedBody!==nextBody){
      try{renderDocument(body,normalizeDocument(article.document));}catch(failure){error='原文结构无法读取：'+failure.message;showMessage();return;}
      heading.textContent=article.title;meta.replaceChildren();const source=make('a',sourceLabel(article));source.href=article.sourceUrl;source.title=article.sourceUrl;source.target='_blank';source.rel='noopener noreferrer';const time=make('time',new Date(article.capturedAt).toLocaleDateString('zh-CN')+' 提取');time.dateTime=article.capturedAt;meta.append(source,time);drawNotes();renderedId=key;renderedBody=nextBody;
    }else if(!notes.contains(dom.activeElement)&&!buffers.get(article.id)?.noteDraft)drawNotes();
  }
  function draw() {
    const article=current();search.hidden=Boolean(article);capture.hidden=Boolean(article);back.hidden=!article;actions.hidden=!article;list.hidden=Boolean(article);detail.hidden=!article;
    actions.replaceChildren();
    if(article){
      actions.append(icon('expand','在独立页面阅读',()=>openReader()),icon('export','导出原文',()=>exportArticle(article)),icon('trash','删除原文',async event=>{if(record||busy())return;const anchor=event.currentTarget;if(!await confirmDelete.ask(anchor,{message:'确认删除这篇本机原文？',label:'确认删除原文',bounds:()=>root.closest('.workspace').getBoundingClientRect()}))return;try{await flushInputs();await send('ORIGINAL_DELETE',{id:article.id});buffers.delete(article.id);showList();}catch(failure){error=failure.message;showMessage();}}));
      actions.lastChild.hidden=Boolean(record);actions.lastChild.disabled=busy()||Boolean(pending);renderDetail();
    }else renderList();
    showMessage();drawFooter();
  }
  async function showArticle(id) {
    error='';if(captureState?.status==='error')dismissedCaptureErrorId=captureState.id;
    remember();flushInputs().catch(()=>{});confirmDelete.close();selectedId=id;record=null;navVersion++;renderedId=null;draw();restore();heading.focus({preventScroll:true});route();persistPrefs();
  }
  function showList() {error='';if(captureState?.status==='error')dismissedCaptureErrorId=captureState.id;remember();flushInputs().catch(()=>{});confirmDelete.close();selectedId=null;record=null;navVersion++;draw();restore();search.value=query;search.focus({preventScroll:true});route();persistPrefs();}
  async function openReader() {
    remember();await flushInputs();await persistPrefs();
    if(!sourceTab && !await chrome.tabs.getCurrent()){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(tab?.id)sourceTab=tab.id;}
    const url=new URL(chrome.runtime.getURL('panel.html'));url.hash='originals';if(record)url.searchParams.set('record',record.id);else url.searchParams.set('article',selectedId);if(sourceTab)url.searchParams.set('sourceTab',sourceTab);
    await chrome.tabs.create({url:url.href});
  }
  function exportArticle(article){if(imageNodes(article.document).length){exportImageArchive([article],article.title).catch(failure=>{error=failure.message;showMessage();});return;}const text=`# ${article.title}\n\n${clipMarkdown(article)}`,url=URL.createObjectURL(new Blob([text],{type:'text/markdown;charset=utf-8'})),a=make('a');a.href=url;a.download=article.title.replace(/[\\/:*?"<>|]/g,'')+'.md';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  async function capturePage() {
    if(busy()||pending)return;const generation=navVersion;requestNavigation=generation;error='';
    operation='capture';showMessage();drawFooter();
    try{await flushInputs();const result=await send('ORIGINAL_CAPTURE',{...(sourceTab?{tabId:sourceTab}:{})});if(active&&generation===navVersion)showArticle(result.id);}
    catch(failure){error=failure.message;showMessage();}finally{operation=null;showMessage();drawFooter();}
  }
  async function resolvePending(accepting) {
    if(!pending||busy())return;operation='update';showMessage();drawFooter();
    try{await flushInputs();const id=pending.articleId;await send(accepting?'ORIGINAL_ACCEPT':'ORIGINAL_REJECT',{pendingId:pending.id});pending=null;if(accepting){delete positions[id];if(current()?.id===id){renderedBody='';renderDetail();restore();}}error='';}
    catch(failure){error=failure.message;}finally{operation=null;showMessage();drawFooter();}
  }
  async function drawFooter() {
    const epoch=++renderEpoch,article=current();if(!active||!article){footer.hidden=true;return;}
    const target=record?.target||prefs.target||'yuque',name=target==='yuque'?'语雀':'飞书',custom=!record&&prefs.yuqueTargets?.[article.id],effective=record?.destinationValues?{...settings,[target]:{...settings[target],...record.destinationValues}}:custom?{...settings,yuque:{...settings.yuque,...custom,configured:true}}:settings;
    const imageCount=imageNodes(article.document).length;if(imageCount){for(const control of footer.querySelectorAll('button'))control.disabled=true;footer.setAttribute('aria-busy','true');}const summary=imageCount?await imageSummary(article):null;if(epoch!==renderEpoch)return;targetPicker?.destroy();footer.replaceChildren();footer.hidden=false;footer.setAttribute('aria-busy','false');
    const imageMode=record?.imageMode||'full',linked=imageCount&&imageMode==='links';
    targetPicker=createChoiceSelect({label:'选择原文保存目标',value:target,options:[{value:'yuque',label:`语雀 · ${isConnected(effective,'yuque')?'私密新建':'未配置'}`},{value:'feishu',label:`飞书 · ${isConnected(settings,'feishu')?'已配置':'未配置'}`}],onChange:value=>{prefs.target=value;persistPrefs();drawFooter();}});
    targetPicker.setDisabled(busy()||Boolean(pending)||Boolean(record));footer.append(targetPicker.element);
    if(imageCount&&summary.blocking)footer.append(make('p',summary.pending?'正在读取图片…':'有图片尚未保留，保存时会请求图片来源权限并重试。','image-save-hint'));
    const saveError=make('p','','error');saveError.hidden=true;saveError.setAttribute('role','status');footer.append(saveError);
    const buffer=buffers.get(article.id),editing=(buffer&&'noteDraft'in buffer?buffer.noteDraft:article.noteDraft)!==null;
    const save=button(operation==='save'?'保存中…':linked&&isConnected(effective,target)?'保存文字与图片链接':isConnected(effective,target)?(record?.status==='failed'?'继续保存到':'保存到')+name:'连接'+name,async()=>{
      if(busy()||pending)return;if(!isConnected(effective,target)){openSettings('targets',target);return;}
      operation='save';operationId=article.id;showMessage();drawNotes();drawFooter();
      try{await flushInputs();if(!record&&imageNodes(article.document).length){const access=await ensureImagesForSave(article);if(access.summary.blocking)throw new Error(access.timedOut?'图片读取超时，请稍后重试保存。':blockReason(article,access.summary));}const result=await send(record?'ORIGINAL_SAVE_RECORD':'ORIGINAL_SAVE',record?{jobId:record.id}:{id:article.id,target,imageMode,...(custom?{yuqueRepo:custom}:{})});if(result.needsSetup)openSettings('targets',target);error='';}
      catch(failure){error=failure.message;}finally{operation=null;operationId=null;const latest=await send('STATE').catch(()=>null);if(latest){jobs=latest.jobs;settings=latest.settings;}if(record)record=jobs.find(item=>item.id===record.id)||record;showMessage();drawNotes();drawFooter();}
    },'primary save-button');save.disabled=busy()||Boolean(pending)||Boolean(!record&&editing);
    const saveRow=make('div','','save-row');
    if(target==='yuque'){repoSelect.setValue({repo:effective.yuque?.repo||'',repoName:effective.yuque?.repoName||''});repoSelect.setDisabled(busy()||Boolean(pending)||Boolean(record));saveRow.append(repoSelect.element);}
    saveRow.append(save);footer.append(saveRow);
    try{
      const hash=await fingerprint(article,target,destinationKey(effective,target),imageMode);if(epoch!==renderEpoch)return;
      const job=record?jobs.find(item=>item.id===record.id)||record:jobs.find(item=>item.clip.id===article.id&&item.target===target&&item.fingerprint===hash);
      if(job&&['saved','pending','uncertain'].includes(job.status)){
        save.hidden=true;const imageHint=footer.querySelector('.image-save-hint');if(imageHint)imageHint.hidden=true;const result=make('div','','saved-line');result.append(make('span',job.status==='saved'?(job.imageMode==='links'?'文字与图片链接已保存':`已保存到${name}`):job.status==='pending'?'保存中…':'结果待核对'));
        if(/^https:\/\//.test(job.url||'')){const link=make('a',job.status==='uncertain'?'检查目标 ↗':'查看 ↗');link.href=job.url;link.target='_blank';link.rel='noopener noreferrer';result.append(link);}footer.append(result);
      }
      if(job?.error){saveError.hidden=false;saveError.textContent=job.error;}
    }catch(failure){saveError.hidden=false;saveError.textContent=failure.message;}
  }

  search.addEventListener('compositionstart',()=>{clearTimeout(searchTimer);search.dataset.composing='true';});
  const filter=()=>{query=search.value;clearTimeout(searchTimer);if(search.dataset.composing==='true')return;searchTimer=setTimeout(()=>{listScroll=0;renderList();persistPrefs();},150);};
  search.addEventListener('compositionend',()=>{search.dataset.composing='false';filter();});search.addEventListener('input',event=>{if(!event.isComposing)filter();});
  dom.getElementById('main').addEventListener('scroll',()=>{if(!active)return;remember();confirmDelete.close();clearTimeout(positionTimer);positionTimer=setTimeout(persistPrefs,180);},{passive:true});
  window.addEventListener('beforeunload',()=>{flushInputs().catch(()=>{});remember();persistPrefs();});
  dom.addEventListener('visibilitychange',()=>{if(dom.hidden){flushInputs().catch(()=>{});remember();persistPrefs();}});
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    if(changes.originals){articles=changes.originals.newValue||[];if(selectedId&&!articles.some(item=>item.id===selectedId)&&!record){selectedId=null;renderedId=null;navVersion++;}if(active){const pos=dom.getElementById('main').scrollTop;draw();dom.getElementById('main').scrollTop=pos;}}
    if(changes.pendingOriginal){pending=changes.pendingOriginal.newValue||null;showMessage();drawFooter();}
    if(changes.imageRevision){drawFooter();}
    if(changes.settings){settings=workbenchSettings(changes.settings.newValue||{});drawFooter();}
    if(changes.jobs){jobs=changes.jobs.newValue||[];if(record)record=jobs.find(item=>item.id===record.id)||record;drawFooter();}
    if(changes.originalCapture){
      captureState=changes.originalCapture.newValue;
      if(captureState?.status==='running'&&captureState.id!==knownRequest){knownRequest=captureState.id;requestNavigation=navVersion;if(captureState.contextMenu)queueMicrotask(()=>{requestNavigation=navVersion;});}
      if(captureState?.status==='ready'&&captureState.id===knownRequest&&active&&navVersion===requestNavigation&&!operation){showArticle(captureState.articleId);}
      showMessage();drawFooter();
    }
  });
  return {
    init(state){articles=state.originals||[];jobs=state.jobs||[];settings=state.settings;pending=state.pendingOriginal;captureState=state.originalCapture;prefs=state.originalWorkspace||{};query=prefs.query||'';listScroll=prefs.listScroll||0;positions=prefs.positions||{};selectedId=params.get('article')||(captureState?.contextMenu&&captureState.status==='ready'?captureState.articleId:null)||prefs.selectedId||null;record=jobs.find(item=>item.id===params.get('record'))||null;if(selectedId&&!articles.some(item=>item.id===selectedId))selectedId=null;search.value=query;draw();},
    show(){active=true;navVersion++;if(initial){knownRequest=captureState?.id;requestNavigation=navVersion;initial=false;}draw();restore();route();},
    hide(){targetPicker?.close();repoSelect.close();remember();active=false;navVersion++;confirmDelete.close();flushInputs().catch(()=>{});persistPrefs();footer.hidden=true;},
    refresh(){showMessage();drawFooter();},
    async openReader(){await openReader();},
    async restoreJob(job){remember();await flushInputs();record=job;selectedId=null;renderedId=null;active=true;navVersion++;draw();restore();route();},
    get dirty(){return writing>0||[...buffers.values()].some(value=>value.notePending);}
  };
}
