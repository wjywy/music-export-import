import { createNoteCard as buildNoteCard } from './lib/note-card.js';
import { anchoredPopover, chevronIcon } from './lib/select.js';
import { exportImageArchive } from './lib/image-export.js';
import { installImageViews } from './lib/image-view.js';
import { imageNodes, renderDocument, documentText } from './lib/article-document.js';
import { imageSummary, ensureImagesForSave, blockReason } from './lib/image-access.js';
import { createOriginalsWorkspace } from './originals.js';
import { createRepoSelect } from './lib/repo-select.js';
import { isConnected, normalizeClip, formatTime, clipMarkdown, fingerprint, destinationKey, destinationLabel, workbenchSettings } from './lib/core.js';
import './lib/messaging.js';
import './lib/confirm-popover.js';
import './lib/note-icons.js';
import './lib/highlight-colors.js';
installImageViews();
const colorTools = globalThis.__shijuColors;
const $ = id => document.getElementById(id);
const send = (type, payload = {}) => __shijuMessaging.send(type, payload);
const make = (tag, text = '', cls = '') => { const node = document.createElement(tag); node.textContent = text; if (cls) node.className = cls; return node; };
const deleteConfirm = __shijuCreateConfirmPopover(document.body);
const fields = ['title', 'text', 'note'];
let state, draft, target = 'yuque', view = 'clip', dirty = false, saving = false, draftTimer, persisting, workspaceTimer, scrolls = {}, version = 0, renderVersion = 0, resumeJob = null, saveError = '', pending = null, externalDraft = null, historyFilter = 'all', historyReturn = 'clip', notesPageKey = new URLSearchParams(location.search).get('page'), notesListScroll = 0, noteDraftTimer;
let richEditor = null;
const searchTimers = new Map();
const originals = createOriginalsWorkspace({ send, root: $('view-originals'), footer: $('original-save-area'), openSettings: openOptions, isVisible: () => view === 'originals', legacyBusy: () => saving });
const repoSelect = createRepoSelect({ send, onChoose: repo => {
  if (!draft) return;
  state.workspace.draftYuque = { draftId: draft.id, repo: repo.namespace, bookId: String(repo.id), repoName: repo.name };
  storeWorkspace(); renderTargets();
} });
$('yuque-destination').append(repoSelect.element);
function notice(message) { $('notice').textContent = message; $('notice').hidden = !message; }
function currentClip() { if (!draft) throw new Error('请先在网页上选中一段文字'); return normalizeClip({ ...draft, ...Object.fromEntries(fields.map(field => [field, $(`clip-${field}`).value])) }); }
function errorAt(id, message) { $(id).textContent = message; $(id).hidden = !message; }
async function storeWorkspace() { clearTimeout(workspaceTimer); await flushNoteDrafts(); return send('WORKSPACE', { patch: { view, target, scroll: scrolls, resumeId: resumeJob?.id || null, draftYuque: state?.workspace?.draftYuque || null, noteTargets: state?.workspace?.noteTargets || {}, notesPageKey, notesQuery: $('notes-search').value, notesListScroll, notesListQuery: state?.workspace?.notesListQuery || '' } }).catch(error => notice(error.message)); }
function showView(next, persist = true) {
  if (!['notes', 'originals', 'history'].includes(next)) next = 'notes';
  if (view === 'originals' && next !== 'originals') originals.hide();
  if (next === 'history' && view !== 'history') { historyReturn = view; historyFilter = state?.jobs?.some(job => ['failed', 'uncertain'].includes(job.status)) ? 'attention' : 'all'; }
  scrolls[view] = $('main').scrollTop; for (const timer of searchTimers.values()) clearTimeout(timer); searchTimers.clear(); deleteConfirm.close();
  view = next; targetOptionsPopup.close(); for (const popup of Object.values(toolsPopovers)) popup.close(); for (const record of noteCards.values()) record.closeMenus(); for (const name of ['clip', 'originals', 'notes', 'history']) $(`view-${name}`).hidden = name !== next;
  const activeTab = next === 'history' ? 'notes' : next;
  for (const button of document.querySelectorAll('[data-tab]')) { if (button.dataset.tab === activeTab) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current'); }
  document.querySelector('nav').hidden = false; $('open-history').setAttribute('aria-expanded', String(next === 'history'));
  history.replaceState(null, '', `#${next}`); if (next === 'notes') renderNotes(); if (next === 'history') renderHistory(); if (next === 'originals') originals.show();
  $('save-area').hidden = true; if (next !== 'originals') $('main').scrollTop = scrolls[next] || 0; if (persist) { persistDraft().catch(() => {}); storeWorkspace(); }
}
function updateHistoryBadge() {
  const count = (state?.jobs || []).filter(job => ['failed', 'uncertain'].includes(job.status)).length;
  const badge = $('history-badge'); badge.hidden = !count; badge.textContent = count > 99 ? '99+' : String(count);
  $('open-history').setAttribute('aria-label', count ? `保存记录，${count} 条需处理` : '保存记录');
}
function updateQuote() { if (draft?.document) { $('quote-display').classList.add('has-images'); renderDocument($('quote-display'), draft.document); } else { $('quote-display').classList.remove('has-images'); $('quote-display').textContent = $('clip-text').value; } requestAnimationFrame(() => { $('expand-quote').hidden = !draft || !$('quote-editor').hidden || ($('quote-display').scrollHeight <= $('quote-display').clientHeight + 2 && $('quote-display').classList.contains('clamped')); }); }
function updateNote() { const text = $('clip-note').value; $('note-preview').textContent = text; $('note-preview-row').hidden = !text || !$('note-editor').hidden; $('add-note').hidden = Boolean(text) || !$('note-editor').hidden; }
function renderDraft(clip) {
  richEditor?.remove();richEditor=null;$('clip-text').hidden=false;clearTimeout(draftTimer); draft = clip ? structuredClone(clip) : null; dirty = false; version++; resumeJob = null; externalDraft = null; saveError = ''; notice('');
  $('empty').hidden = Boolean(draft); $('clip-form').hidden = !draft; $('save-area').hidden = true;
  $('quote-editor').hidden = true; $('quote-display').hidden = false; $('quote-display').classList.add('clamped'); $('edit-quote').hidden = false; $('expand-quote').textContent = '展开原文'; $('source-details').hidden = true; $('source-details-toggle').setAttribute('aria-expanded', 'false'); $('note-editor').hidden = true;
  if (!draft) { renderTargets(); return; }
  for (const field of fields) $(`clip-${field}`).value = draft[field] || '';
  const url = new URL(draft.sourceUrl); $('source-link').textContent = url.hostname; $('source-link').href = draft.sourceUrl; $('source-link').title = draft.sourceTitle || draft.sourceUrl;
  $('full-source-title').textContent = draft.sourceTitle; $('full-source-link').textContent = draft.sourceUrl; $('full-source-link').href = draft.sourceUrl; $('capture-time').textContent = `采集于 ${formatTime(draft.capturedAt)}`;
  updateQuote(); updateNote(); renderTargets();
}
function edited() {
  if (!draft) return; dirty = true; version++; saveError = ''; state.draftEdited = true;
  if (!draft.marked) { draft.marked = true; send('EDIT_STARTED', { id: draft.id }).catch(error => notice(error.message)); }
  clearTimeout(draftTimer); draftTimer = setTimeout(() => persistDraft().catch(() => {}), 180); updateQuote(); updateNote(); renderTargets();
}
async function persistDraft() {
  clearTimeout(draftTimer); if (persisting) await persisting; if (!dirty || !draft) return;
  let snapshot; try { snapshot = currentClip(); } catch (error) { notice(`草稿未保留：${error.message}`); throw error; }
  const generation = version; const expectedId = draft.id;
  persisting = send('DRAFT', { clip: snapshot, expectedId });
  try { await persisting; if (draft?.id === expectedId && version === generation) { dirty = false; draft = { ...snapshot, marked: true }; notice(''); } }
  catch (error) { notice(`草稿未保留：${error.message}`); throw error; }
  finally { persisting = null; }
}
function draftDestination() {
  const saved = state?.workspace?.draftYuque;
  if (!draft || !saved || saved.draftId !== draft.id || !saved.repo) return null;
  return { repo: saved.repo, bookId: saved.bookId, repoName: saved.repoName || '' };
}
function effectiveSettings() {
  if (resumeJob?.target === target && resumeJob.destinationValues) return { ...state.settings, [target]: { ...state.settings[target], ...resumeJob.destinationValues } };
  const custom = target === 'yuque' ? draftDestination() : null;
  return custom ? { ...state.settings, yuque: { ...state.settings.yuque, ...custom } } : state.settings;
}
function renderTargets() {
  if (!state) return; originals.refresh(); document.body.dataset.reducedMotion = String(state.settings.motion === 'reduce');
  for (const name of ['yuque', 'feishu']) { $(`${name}-status`).textContent = isConnected(state.settings, name) ? '已配置' : '未配置'; const button = document.querySelector(`[data-target=${name}]`); button.disabled = saving; button.setAttribute('aria-pressed', String(name === target)); }
  const name = target === 'yuque' ? '语雀' : '飞书', settings = effectiveSettings();
  $('destination-hint').textContent = target === 'yuque' ? `语雀 · ${isConnected(state.settings, 'yuque') ? '私密新建' : '未配置'}` : `${name} · ${destinationLabel(settings, target)}`; $('target-full').textContent = `${name} · ${destinationLabel(settings, target)}`;
  $('yuque-destination').hidden = target !== 'yuque';
  repoSelect.setValue({ repo: settings.yuque?.repo || '', repoName: settings.yuque?.repoName || '' });
  repoSelect.setDisabled(saving || Boolean(resumeJob));
  $('target-summary').disabled = saving; $('manage-connections').disabled = saving;
  $('save').textContent = saving ? '保存中…' : isConnected(state.settings, target) ? `${resumeJob ? '继续保存到' : '保存到'}${name}` : `连接${name}`;
  $('save').disabled = saving; $('save').dataset.imageMode=resumeJob?.imageMode||'full'; $('save').hidden = false; $('save-result').hidden = true; $('result-link').hidden = true; $('show-save-record').hidden = true; errorAt('save-error', saveError);
  if (!draft || saving) return;
  $('image-save-hint').hidden=true;
  const check = ++renderVersion; let clip; try { clip = currentClip(); } catch { return; }
  const key = destinationKey(settings, target), requestedTarget = target;
  (async()=>{
    const images=imageNodes(clip.document),summary=images.length?await imageSummary(clip):null;
    const imageMode=resumeJob?.imageMode||'full';
    if(check!==renderVersion||saving||requestedTarget!==target)return null;
    if(images.length){
      const hint=$('image-save-hint');
      hint.textContent=summary.pending?'正在读取图片…':summary.blocking?'有图片尚未保留，保存时会请求图片来源权限并重试。':summary.skipped?`有 ${summary.skipped} 张图片无法保留，将显示占位说明。`:'';hint.hidden=!hint.textContent;
      $('save').dataset.imageMode=imageMode;
      if(imageMode==='links'&&isConnected(state.settings,target))$('save').textContent='保存文字与图片链接';
    }
    return fingerprint(clip,target,key,imageMode);
  })().then(hash => {
    if(!hash)return;
    if (check !== renderVersion || saving || requestedTarget !== target) return;
    const job = (state.jobs || []).find(job => job.clip.id === clip.id && job.target === target && job.fingerprint === hash);
    if (!job) return;
    if (job.status === 'saved' || job.status === 'uncertain' || job.status === 'pending') {
      $('image-save-hint').hidden=true;
      $('save').hidden = true; $('save-result').hidden = false; $('save-result-text').textContent = job.status === 'saved' ? (job.imageMode === 'links' ? '文字与图片链接已保存' : `已保存到${name}`) : job.status === 'uncertain' ? '结果待核对' : '保存中…';
      if (job.url && /^https:\/\//.test(job.url)) { $('result-link').href = job.url; $('result-link').textContent = job.status === 'uncertain' ? '检查目标 ↗' : '查看 ↗'; $('result-link').hidden = false; }
      if (job.status === 'uncertain') { errorAt('save-error', job.error || '请先检查目标文档，避免重复写入。'); $('show-save-record').hidden = false; }
    } else if (job.status === 'failed') errorAt('save-error', `${job.nextBlock || job.documentId && job.destinationValues?.mode === 'new' ? '部分内容已保存。' : ''}${saveError || job.error || '保存未完成，请重试。'}`);
  }).catch(error => notice(error.message));
}
async function openOptions(section, provider) { try { await persistDraft(); } catch {} try { await send('OPEN_OPTIONS', { section, provider }); } catch (error) { notice(error.message); } }
async function confirmReplacement() { if (!draft) return true; if ((dirty || state.draftEdited) && !confirm('替换当前已编辑的摘录草稿？取消可继续编辑当前内容。')) return false; await persistDraft().catch(() => {}); return true; }
function renderPending() {
  const visible = Boolean(pending || externalDraft); $('pending-capture').hidden = !visible;
  if (visible) $('pending-capture').querySelector('p').textContent = externalDraft ? '另一个工作台有新剪藏，是否切换？当前输入仍保留。' : '有新的剪藏，替换当前草稿？';
}
$('replace-capture').onclick = async () => {
  if (saving) return; $('replace-capture').disabled = true;
  try { await persistDraft().catch(() => {}); if (externalDraft) { renderDraft(externalDraft); externalDraft = null; } else { const result = await send('ACCEPT_CAPTURE', { id: pending.id }); if (result.target) target = result.target; renderDraft(result.clip); pending = null; } renderPending(); renderTargets(); showView('notes'); }
  catch (error) { notice(error.message); } finally { $('replace-capture').disabled = false; }
};
$('keep-capture').onclick = async () => { try { if (externalDraft) { await send('DRAFT', { clip: currentClip(), expectedId: externalDraft.id }); state.draftEdited = true; } if (pending) await send('REJECT_CAPTURE', { id: pending.id }); pending = null; externalDraft = null; renderPending(); } catch (error) { notice(error.message); } };
for (const button of document.querySelectorAll('[data-tab]')) button.onclick = () => { if (button.dataset.tab === 'notes' && view === 'notes' && notesPageKey) returnToNotesList(); else showView(button.dataset.tab); };
for (const button of document.querySelectorAll('[data-target]')) button.onclick = () => { if (saving) return; target = button.dataset.target; resumeJob = null; saveError = ''; targetOptionsPopup.close(true); renderTargets(); storeWorkspace(); $('target-summary').focus({ preventScroll: true }); };
$('target-summary').lastElementChild.replaceChildren(chevronIcon());
$('target-options').classList.add('control-menu');
const targetOptionsPopup = anchoredPopover($('target-summary'), $('target-options'), { focus: () => document.querySelector(`[data-target=${target}]`) });
function toggleTargets(open) { open ? targetOptionsPopup.open() : targetOptionsPopup.close(true); }
$('target-summary').onclick = event => toggleTargets($('target-options').hidden, event.detail === 0);
$('target-summary').onkeydown = event => { if (event.key === 'ArrowDown') { event.preventDefault(); toggleTargets(true, true); } };
$('target-options').onkeydown = event => { if (event.key === 'Escape') { event.preventDefault(); toggleTargets(false); $('target-summary').focus({ preventScroll: true }); } else if (['ArrowDown', 'ArrowUp'].includes(event.key) && event.target.matches('[data-target]')) { event.preventDefault(); document.querySelector(`[data-target=${event.target.dataset.target === 'yuque' ? 'feishu' : 'yuque'}]`).focus({ preventScroll: true }); } };
$('settings').onclick = () => openOptions(); $('manage-connections').onclick = () => openOptions('targets', target);
$('expand').onclick = async () => { if (view === 'originals') return originals.openReader().catch(error => notice(error.message)); await storeWorkspace(); const url = new URL(chrome.runtime.getURL('panel.html')); url.hash = view; if (notesPageKey) url.searchParams.set('page', notesPageKey); if ($('notes-search').value) url.searchParams.set('q', $('notes-search').value); await chrome.tabs.create({ url: url.href }); };
$('show-save-record').onclick = () => showView('history');
for (const field of fields) $(`clip-${field}`).addEventListener('input', edited);
let originalQuote = ''; 
$('edit-quote').onclick = () => {
  originalQuote=$('clip-text').value;$('quote-editor').hidden=false;$('quote-display').hidden=true;$('edit-quote').hidden=true;$('expand-quote').hidden=true;
  if(draft?.document){
    richEditor=make('div','','image-text-editor');richEditor.fields=[];
    // Each editable text leaf stays at its AST position; image references are never rewritten as text.
    const walk=value=>{if(!value||typeof value!=='object')return;if(value.type==='image'){const image=make('div');renderDocument(image,[value]);richEditor.append(image);return;}if(typeof value.text==='string'){const input=make('textarea');input.rows=2;input.value=value.text;input.setAttribute('aria-label','剪藏文字第'+(richEditor.fields.length+1)+'段');richEditor.fields.push({value,input});richEditor.append(input);return;}for(const item of Object.values(value))if(Array.isArray(item))item.forEach(walk);else if(item&&typeof item==='object')walk(item);};
    walk(draft.document);$('clip-text').hidden=true;$('quote-editor').prepend(richEditor);richEditor.querySelector('textarea')?.focus();
  }else $('clip-text').focus();
};
function closeQuote() { richEditor?.remove();richEditor=null;$('clip-text').hidden=false; $('quote-editor').hidden = true; $('quote-display').hidden = false; $('edit-quote').hidden = false; updateQuote(); $('edit-quote').focus(); }
$('done-quote').onclick = () => { try { if(richEditor){for(const {value,input}of richEditor.fields)value.text=input.value;$('clip-text').value=documentText(draft.document);edited();} currentClip(); closeQuote(); persistDraft().catch(() => {}); } catch (error) { notice(error.message); } };
$('cancel-quote').onclick = () => { $('clip-text').value = originalQuote; edited(); closeQuote(); };
$('expand-quote').onclick = () => { const collapsed = $('quote-display').classList.toggle('clamped'); $('expand-quote').textContent = collapsed ? '展开原文' : '收起原文'; };
$('source-details-toggle').onclick = () => { $('source-details').hidden = !$('source-details').hidden; $('source-details-toggle').setAttribute('aria-expanded', String(!$('source-details').hidden)); };
function editClipNote() { $('note-editor').hidden = false; updateNote(); $('clip-note').focus(); }
$('add-note').onclick = editClipNote; $('edit-clip-note').onclick = editClipNote;
$('done-note').onclick = () => { $('note-editor').hidden = true; updateNote(); persistDraft().catch(() => {}); };
$('clip-form').onsubmit = async event => {
  event.preventDefault(); if (saving || !draft) return;
  if (!isConnected(state.settings, target)) { await openOptions('targets', target); return; }
  let snapshot; try { snapshot = currentClip(); } catch (error) { errorAt('save-error', error.message); return; }
  const capturedTarget=target,expectedId=draft.id,continuation=resumeJob?.id,imageMode=resumeJob?.imageMode||$('save').dataset.imageMode||'full';saving=true; saveError = ''; renderTargets();
  try {
    if (imageMode !== 'links' && imageNodes(snapshot.document).length) {
      $('image-save-hint').hidden = false; $('image-save-hint').textContent = '正在准备图片…';
      const access = await ensureImagesForSave(snapshot);
      if (access.summary.blocking) throw new Error(access.timedOut ? '图片读取超时，请稍后重试保存。' : blockReason(snapshot, access.summary));
    }
    await persistDraft();
    const customRepo = !continuation && capturedTarget === 'yuque' ? draftDestination() : null;
    const result = await send('SAVE', { clip: snapshot, target: capturedTarget, expectedId, resumeId: continuation, imageMode, ...(customRepo ? { yuqueRepo: customRepo } : {}) }); if (result.needsSetup) await openOptions('targets', capturedTarget);
  }
  catch (error) { if (draft?.id === expectedId && capturedTarget === target) saveError = error.message; }
  finally { saving = false; try { const latest = await send('STATE'); state.jobs = latest.jobs; state.settings = latest.settings; } catch (error) { notice(error.message); } renderTargets(); }
};
function search(id, callback) {
  const input = $(id); let composing = false;
  const queue = () => { clearTimeout(searchTimers.get(id)); if (composing) return; if (!input.value) { callback(); return; } searchTimers.set(id, setTimeout(() => { searchTimers.delete(id); callback(); }, 150)); };
  input.addEventListener('compositionstart', () => { composing = true; clearTimeout(searchTimers.get(id)); }); input.addEventListener('compositionend', () => { composing = false; queue(); }); input.addEventListener('input', event => { if (!event.isComposing) queue(); });
}

const noteCards = new Map();
const pendingNoteDrafts = new Map();
let noteDraftWriting;
function changeNoteDraft(id, value) {
  if (value) state.workspace.noteDrafts = { ...(state.workspace.noteDrafts || {}), [id]: value };
  else if (state.workspace.noteDrafts) delete state.workspace.noteDrafts[id];
  pendingNoteDrafts.set(id, value);
  clearTimeout(noteDraftTimer); noteDraftTimer = setTimeout(() => flushNoteDrafts().catch(error => notice(error.message)), 150);
}
async function flushNoteDrafts() {
  clearTimeout(noteDraftTimer);
  if (noteDraftWriting) await noteDraftWriting;
  if (!pendingNoteDrafts.size) return;
  const changes = [...pendingNoteDrafts]; pendingNoteDrafts.clear();
  noteDraftWriting = Promise.all(changes.map(async ([id, draft]) => { try { await send('NOTE_DRAFT', { id, draft }); } catch (error) { if (!pendingNoteDrafts.has(id)) pendingNoteDrafts.set(id, draft); throw error; } }));
  try { await noteDraftWriting; } finally { noteDraftWriting = null; }
}
function createNoteCard(item) {
  return buildNoteCard(item, { send, getState: () => state, getDraft: id => state.workspace.noteDrafts?.[id], changeDraft: changeNoteDraft, confirm: deleteConfirm, openOptions,
    saved: async next => { if (next) { const index = state.annotations.findIndex(item => item.id === next.id); if (index >= 0) state.annotations[index] = next; renderNotes(); } await storeWorkspace(); },
    removed: id => { state.annotations = state.annotations.filter(item => item.id !== id); renderNotes(); storeWorkspace(); }
  });
}
function returnToNotesList() {
  const key = notesPageKey; notesPageKey = null; $('notes-search').value = state.workspace.notesListQuery || ''; renderNotes(); $('main').scrollTop = notesListScroll;
  [...$('notes-list').querySelectorAll('.note-page')].find(row => row.dataset.pageKey === key)?.focus({ preventScroll: true }); storeWorkspace();
}
$('notes-back').onclick = returnToNotesList;

function noteMatches(item, query) {
  return !query || `${item.clip.title}\n${item.clip.sourceTitle}\n${item.clip.text}\n${item.clip.note}`.toLowerCase().includes(query);
}
function noteGroups() {
  const map = new Map();
  for (const item of state.annotations || []) {
    const key = item.pageKey || item.clip.sourceUrl;
    if (!map.has(key)) map.set(key, { key, items: [] });
    map.get(key).items.push(item);
  }
  return [...map.values()].map(group => {
    const items = [...group.items].sort((a, b) => Date.parse(b.updatedAt || b.createdAt) - Date.parse(a.updatedAt || a.createdAt));
    const latest = items[0];
    const notes = items.filter(item => Boolean(String(item.clip.note || '').trim())).length;
    let domain = '';
    try { domain = new URL(latest.clip.sourceUrl).hostname; } catch {}
    return { ...group, items, latest, notes, highlights: items.length, title: latest.clip.sourceTitle || latest.clip.title || '笔记', domain };
  }).sort((a, b) => Date.parse(b.latest.updatedAt || b.latest.createdAt) - Date.parse(a.latest.updatedAt || a.latest.createdAt));
}
function renderNotes() {
  const head = $('notes-head'), list = $('notes-list'), query = $('notes-search').value.trim().toLowerCase();
  const groups = noteGroups(), group = notesPageKey ? groups.find(item => item.key === notesPageKey) : null;
  if (!group) notesPageKey = null;
  $('notes-back').hidden = !group; $('notes-overview').hidden = Boolean(group); $('notes-overview').textContent = `全部笔记 · ${groups.length} 篇`;
  $('notes-search').placeholder = group ? '搜索本文摘录或批注…' : '搜索全部笔记…'; $('notes-search').setAttribute('aria-label', $('notes-search').placeholder.replace('…',''));
  $('export-page-notes').hidden = !group; $('export-page-notes').disabled = !group?.items.length;
  $('export-notes').disabled = !state.annotations.length;
  if (!group) {
    head.hidden = true; head.replaceChildren(); list.replaceChildren();
    const visible = groups.filter(item => item.items.some(note => noteMatches(note, query)));
    $('notes-results').textContent = query ? `找到 ${visible.length} 篇匹配网页` : '';
    if (!visible.length) list.append(make('p', query ? '没有找到匹配的笔记。' : '选中网页文字，点「笔记」写下批注。', 'history-empty'));
    for (const item of visible) {
      const row = make('button', '', 'note-page'); row.type = 'button'; row.dataset.pageKey = item.key;
      const main = make('span', '', 'note-page-main'), title = make('strong', item.title, 'note-page-title'); title.title = item.title;
      main.append(title, make('small', `${item.domain ? item.domain + ' · ' : ''}${item.highlights} 处标注 · ${item.notes} 条批注`, 'note-page-meta'));
      row.append(main, make('span', '›', 'note-page-chevron'));
      row.onclick = () => { notesListScroll = $('main').scrollTop; state.workspace.notesListQuery = $('notes-search').value; notesPageKey = item.key; $('notes-search').value = ''; renderNotes(); $('main').scrollTop = 0; $('notes-back').focus({ preventScroll: true }); storeWorkspace(); };
      list.append(row);
    }
  } else {
    head.hidden = false;
    let title = head.querySelector('h2'), stats = head.querySelector('small');
    if (!title) { title = make('h2'); stats = make('small'); head.append(title, stats); }
    title.textContent = group.title; title.title = group.title;
    stats.textContent = `${group.domain ? group.domain + ' · ' : ''}${group.highlights} 处标注 · ${group.notes} 条批注`;
    const items = group.items.filter(item => noteMatches(item, query)); $('notes-results').textContent = query ? `找到 ${items.length} 条匹配标注` : '';
    const desired = items.map(item => { if (!noteCards.has(item.id)) noteCards.set(item.id, createNoteCard(item)); const record = noteCards.get(item.id); record.update(item); return record.article; });
    if (!desired.length) desired.push(make('p', query ? '没有匹配的摘录或批注。' : '这篇网页还没有标注。', 'history-empty'));
    const keep = new Set(desired); for (const child of [...list.children]) if (!keep.has(child)) child.remove();
    desired.forEach((node, index) => { if (list.children[index] !== node) list.insertBefore(node, list.children[index] || null); });
  }
  const ids = new Set(state.annotations.map(item => item.id));
  for (const [id, record] of noteCards) if (!ids.has(id)) { record.destroy(); noteCards.delete(id); }
  const url = new URL(location.href); if (notesPageKey) url.searchParams.set('page', notesPageKey); else url.searchParams.delete('page');
  if (query) url.searchParams.set('q', $('notes-search').value); else url.searchParams.delete('q'); history.replaceState(null, '', url);
}

const historyDetails = new Set();
async function restoreJob(job, asNew = false) {
  if (job.status === 'pending') return;
  if (job.clip.kind === 'page') { showView('originals'); await originals.restoreJob(job); return; }
  if (asNew && !confirm('上次写入结果不确定，内容可能已经保存。请先检查目标；恢复为新摘录后再次保存可能重复。继续？')) return;
  try { if (!await confirmReplacement()) return; const clip = await send('RESTORE', { id: job.id, asNew, replaceConfirmed: true }); state.draftEdited = false; target = job.target; renderDraft(clip); if (job.target === 'yuque' && job.destinationValues?.repo) state.workspace.draftYuque = { draftId: clip.id, repo: job.destinationValues.repo, bookId: String(job.destinationValues.bookId || ''), repoName: job.destinationValues.repoName || '' }; if (!asNew && job.status === 'failed') { const latest = await send('STATE'); state.jobs = latest.jobs; resumeJob = state.jobs.find(item => item.id === job.id) || job; } renderTargets(); showView('notes'); }
  catch (error) { notice(error.message); }
}
function renderHistory() {
  updateHistoryBadge();
  const list = $('history-list'); list.replaceChildren(); const query = $('history-search').value.trim().toLowerCase();
  const hasAttention = state.jobs.some(job => ['failed', 'uncertain'].includes(job.status)); $('history-filters').hidden = !hasAttention; if (!hasAttention) historyFilter = 'all';
  for (const button of document.querySelectorAll('[data-filter]')) button.classList.toggle('active', button.dataset.filter === historyFilter);
  const jobs = [...state.jobs].sort((a, b) => Date.parse(b.updatedAt || b.createdAt) - Date.parse(a.updatedAt || a.createdAt)).filter(job => (historyFilter === 'all' || ['failed', 'uncertain'].includes(job.status)) && `${job.clip.title}\n${job.clip.text}\n${job.clip.note}\n${job.destination || ''}`.toLowerCase().includes(query));
  if (!jobs.length) list.append(make('p', query ? '没有找到匹配的记录。' : historyFilter === 'attention' ? '没有需要处理的记录。' : '还没有剪藏记录。', 'history-empty'));
  for (const job of jobs) {
    const item = make('article', '', 'history-item'); item.dataset.jobId = job.id;
    const title = make('h2', job.clip.title || '未命名记录', 'history-title');
    const meta = make('div', '', 'history-meta'); meta.append(make('span', `${job.target === 'yuque' ? '语雀' : '飞书'} · ${formatTime(job.updatedAt || job.createdAt)}`));
    const partial = job.status === 'failed' && Boolean(job.nextBlock || job.documentId && job.destinationValues?.mode === 'new'); meta.append(make('span', partial ? '部分成功' : { saved: job.imageMode==='links'?'文字与图片链接已保存':'已保存', failed: '未保存', pending: '保存中', uncertain: '待核对' }[job.status] || '待核对', `status-label ${job.status}`));
    item.append(title, meta); if (job.error) item.append(make('p', job.error, 'history-error'));
    const actions = make('div', '', 'history-actions');
    if (job.url && /^https:\/\//.test(job.url)) { const link = make('a', job.status === 'uncertain' ? '检查目标 ↗' : '查看 ↗'); link.href = job.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; actions.append(link); }
    if (job.status === 'failed') { const restore = make('button', '继续处理', 'text-action'); restore.onclick = () => restoreJob(job); actions.append(restore); }
    const details = make('details', '', 'history-details'); details.open = historyDetails.has(job.id); details.append(make('summary', '详情'), make('pre', clipMarkdown(job.clip)), make('p', `目标：${job.destination || job.target}`));
    details.ontoggle = () => { if (details.open) historyDetails.add(job.id); else historyDetails.delete(job.id); };
    if (job.status === 'uncertain') details.append(make('p', '内容可能已经写入，请先检查目标。不自动重发。'));
    if (job.status === 'saved' || job.status === 'uncertain') { const restore = make('button', job.clip.kind === 'page' ? '查看原文快照' : job.status === 'uncertain' ? '恢复为新摘录' : '恢复编辑', 'text-action'); restore.onclick = () => restoreJob(job, job.status === 'uncertain'); details.append(restore); }
    item.append(actions, details); list.append(item);
  }
  $('clear-history').disabled = !state.jobs.length;
}
$('open-history').onclick = () => { if (view === 'history') { showView(historyReturn || 'clip'); $('open-history').focus({ preventScroll: true }); } else { showView('history'); $('close-history').focus({ preventScroll: true }); } };
$('close-history').onclick = () => { showView(historyReturn || 'clip'); $('open-history').focus({ preventScroll: true }); };
document.addEventListener('keydown', event => { if (event.key === 'Escape' && view === 'history' && !event.defaultPrevented) { event.preventDefault(); showView(historyReturn || 'clip'); $('open-history').focus({ preventScroll: true }); } });
for (const button of document.querySelectorAll('[data-filter]')) button.onclick = () => { historyFilter = button.dataset.filter; renderHistory(); };
search('notes-search', renderNotes); search('history-search', renderHistory);
const toolsPopovers = Object.fromEntries(['notes', 'history'].map(type => { const trigger = $(`${type}-tools-toggle`), menu = $(`${type}-tools`); menu.classList.add('control-menu'); const popup = anchoredPopover(trigger, menu); trigger.onclick = () => popup.toggle(); return [type, popup]; }));
function download(markdown, name) { const url = URL.createObjectURL(new Blob([markdown], { type: 'text/markdown;charset=utf-8' })); const link = make('a'); link.href = url; link.download = `${name}-${new Date().toISOString().slice(0, 10)}.md`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
$('export').onclick = () => {if(state.jobs.some(job=>imageNodes(job.clip.document).length)){exportImageArchive(state.jobs.map(job=>job.clip),'拾句记录').catch(error=>notice(error.message));return;}download(state.jobs.map(job => `# ${job.clip.title}\n\n平台：${job.target === 'yuque' ? '语雀' : '飞书'} · 状态：${job.status}\n\n${clipMarkdown(job.clip)}${job.destination ? `\n\n目标：${job.destination}` : ''}${job.url ? `\n\n链接：${job.url}` : ''}`).join('\n\n---\n\n') || '# 拾句\n\n暂无记录', '拾句记录');};
function exportNotes(items, name) { if (!items.length) return; download(items.map(item => `# ${item.clip.title}\n\n高亮颜色：${colorTools.label(item.color)}\n\n${clipMarkdown(item.clip)}`).join('\n\n---\n\n'), name); toolsPopovers.notes.close(true); }
$('export-notes').onclick = () => exportNotes(state.annotations, '拾句全部笔记');
$('export-page-notes').onclick = () => exportNotes(noteGroups().find(group => group.key === notesPageKey)?.items || [], '拾句本文标注');
$('clear-history').onclick = async () => { if (!confirm('清空本机剪藏记录？语雀和飞书中的文档不会删除。')) return; try { await send('CLEAR_HISTORY'); state.jobs = []; updateHistoryBadge(); renderHistory(); renderTargets(); } catch (error) { notice(error.message); } };
$('main').addEventListener('scroll', () => { scrolls[view] = $('main').scrollTop; clearTimeout(workspaceTimer); workspaceTimer = setTimeout(storeWorkspace, 200); }, { passive: true });
document.addEventListener('visibilitychange', () => { if (document.hidden) { persistDraft().catch(() => {}); storeWorkspace(); } });
window.addEventListener('beforeunload', event => { if (dirty || originals.dirty || pendingNoteDrafts.size || noteDraftWriting) { event.preventDefault(); event.returnValue = ''; } });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !state) return;
  if (changes.originalCapture?.newValue?.contextMenu && changes.originalCapture.newValue.status === 'running' && view !== 'originals') showView('originals');
  if (changes.workspace?.newValue) {
    const remote = changes.workspace.newValue, drafts = { ...(remote.noteDrafts || {}) };
    for (const [id, draft] of pendingNoteDrafts) { if (draft) drafts[id] = draft; else delete drafts[id]; }
    for (const [id, record] of noteCards) if (record.dirty) drafts[id] = record.serialize();
    state.workspace.noteDrafts = drafts;
    state.workspace.noteTargets = remote.noteTargets || state.workspace.noteTargets || {};
  }
  if (changes.settings) { state.settings = workbenchSettings(changes.settings.newValue || {}); saveError = ''; renderTargets(); }
  if (changes.imageRevision) renderTargets();
  if (changes.jobs) { state.jobs = changes.jobs.newValue || []; updateHistoryBadge(); if (view === 'history') renderHistory(); renderTargets(); }
  if (changes.annotations) { state.annotations = changes.annotations.newValue || []; if (view === 'notes') renderNotes(); }
    if (changes.draft) {
    const value = changes.draft.newValue;
    if (value?.id !== draft?.id) {
      if (dirty || state.draftEdited) { externalDraft = value; renderPending(); }
      else { if (['yuque', 'feishu'].includes(changes.workspace?.newValue?.target)) target = changes.workspace.newValue.target; renderDraft(value); showView('notes'); }
    }
    state.draft = value;
  }
  if (changes.draftEdited) state.draftEdited = Boolean(changes.draftEdited.newValue);
  if (changes.pendingCapture) { pending = changes.pendingCapture.newValue || null; renderPending(); }
});
$('edit-quote').append(__shijuNoteIcon('edit')); $('edit-clip-note').append(__shijuNoteIcon('edit')); $('settings').append(__shijuNoteIcon('settings'));
try {
  state = await send('STATE'); state.workspace ||= {}; notesPageKey ||= state.workspace.notesPageKey || null; notesListScroll = state.workspace.notesListScroll || 0; $('notes-search').value = new URLSearchParams(location.search).get('q') ?? state.workspace.notesQuery ?? ''; target = state.workspace.target || (isConnected(state.settings, 'yuque') ? 'yuque' : isConnected(state.settings, 'feishu') ? 'feishu' : 'yuque'); scrolls = state.workspace.scroll || {};
  view = ['notes', 'originals', 'history'].includes(location.hash.slice(1)) ? location.hash.slice(1) : state.workspace.view || 'notes';
  originals.init(state); renderDraft(state.draft); resumeJob = state.jobs.find(job => job.id === state.workspace.resumeId) || null; renderTargets(); pending = state.pendingCapture; renderPending(); updateHistoryBadge(); showView(view, false);
  if (location.hash === '#settings') openOptions();
} catch (error) { notice(error.message); }
