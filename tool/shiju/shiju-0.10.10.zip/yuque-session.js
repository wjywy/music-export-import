// Fixed, same-origin adapter. Login credentials never leave this isolated world.
(() => {
  if (location.origin !== 'https://www.yuque.com' || window.top !== window) return;
  const MAX = globalThis.__shijuImagePolicy.single;
  const failure = (message, uncertain = false) => Object.assign(new Error(message), { uncertain });
  const userId = value => /^[1-9]\d{0,19}$/.test(String(value)) ? String(value) : '';
  const csrf = () => {
    const item = document.cookie.split(';').map(value => value.trim()).find(value => value.startsWith('yuque_ctoken='));
    let value = ''; try { value = decodeURIComponent(item?.slice('yuque_ctoken='.length) || ''); } catch {}
    if (!value) { value = crypto.randomUUID().replace(/-/g, ''); document.cookie = `yuque_ctoken=${value}; Path=/; Secure; SameSite=Lax`; if (!document.cookie.split(';').some(entry => entry.trim() === `yuque_ctoken=${value}`)) throw failure('语雀无法保存验证信息，请允许语雀使用Cookie后重试保存。'); }
    if (value.length > 1000 || /[\r\n]/.test(value)) throw failure('语雀登录状态异常，请重新登录后保存。');
    return value;
  };
  async function mine() {
    let response, body;
    try { response = await fetch('/api/mine', { credentials:'same-origin', redirect:'error', cache:'no-store', signal:AbortSignal.timeout(10000) }); body = await response.json(); }
    catch { throw failure('无法确认语雀登录状态，请刷新语雀网页后重试。'); }
    if (!response.ok || !userId(body?.data?.id)) throw Object.assign(failure('请在已打开的语雀页面登录，完成后返回拾句保存。'),{needsLogin:true});
    csrf();
    return { userId:userId(body.data.id), name:String(body.data.name || body.data.login || '语雀用户').slice(0,140), login:String(body.data.login || '').slice(0,120) };
  }
  async function repos() {
    const user = await mine();
    let response, body;
    try { response = await fetch('/api/mine/books', { credentials:'same-origin', redirect:'error', cache:'no-store', signal:AbortSignal.timeout(10000) }); body = await response.json().catch(() => ({})); }
    catch { throw failure('无法读取语雀知识库列表，请刷新语雀网页后重试。'); }
    if (!response.ok) {
      try { response = await fetch('/api/mine/personal_books?limit=200&offset=0', { credentials:'same-origin', redirect:'error', cache:'no-store', signal:AbortSignal.timeout(10000) }); body = await response.json().catch(() => ({})); }
      catch { throw failure('无法读取语雀知识库列表，请刷新语雀网页后重试。'); }
    }
    if (!response.ok) throw Object.assign(failure(response.status === 401 || response.status === 403 ? '请在语雀登录后重新读取知识库。' : '读取语雀知识库失败，请稍后重试。'), { needsLogin: response.status === 401 });
    const list = Array.isArray(body?.data) ? body.data : Array.isArray(body?.data?.books) ? body.data.books : [];
    const items = list.filter(item => item && typeof item === 'object' && item.id && (item.type === undefined || item.type === 'Book') && (item.slug || item.namespace))
      .map(item => {
        const slug = String(item.slug || String(item.namespace || '').split('/').at(-1) || '').slice(0,120);
        const owner = /^[\w-]+$/.test(String(item.user?.login || '')) ? String(item.user.login) : user.login;
        const namespace = /^[\w-]+\/[\w-]+$/.test(String(item.namespace || '')) ? String(item.namespace) : owner && slug ? `${owner}/${slug}` : '';
        return { id: String(item.id), name: String(item.name || slug).slice(0,200), slug, namespace, public: Number(item.public) || 0, description: String(item.description || '').slice(0,500) };
      })
      .filter(item => /^[\w-]+\/[\w-]+$/.test(item.namespace))
      .sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
    return { user, repos: items };
  }
  async function createDoc(message) {
    const repo = String(message?.repo || '').trim();
    if (!/^[\w-]+\/[\w-]+$/.test(repo)) throw failure('知识库标识无效，请重新选择知识库。');
    const bookId = Number(message?.bookId);
    if (!Number.isSafeInteger(bookId) || bookId <= 0) throw failure('知识库编号无效，请重新选择知识库。');
    const title = String(message?.title || '').slice(0, 500);
    const slug = String(message?.slug || '').slice(0, 120);
    if (!title.trim() || !/^[\w-]{1,120}$/.test(slug)) throw failure('文档标题或地址无效。');
    if (typeof message?.body !== 'string' || !message.body.length || message.body.length > 4_000_000) throw failure('文档内容为空或过长。');
    const current = await mine();
    const token = csrf();
    let response, body;
    try {
      response = await fetch('/api/docs', {
        method:'POST', credentials:'same-origin', redirect:'error', cache:'no-store',
        headers:{'Content-Type':'application/json; charset=UTF-8','x-csrf-token':token},
        body: JSON.stringify({ type:'Doc', format:'markdown', status:1, public:0, title:title.trim(), book_id:bookId, body:message.body, body_draft_asl:'', body_asl:'', insert_to_catalog:true }),
        signal: AbortSignal.timeout(globalThis.__shijuImagePolicy.uploadTimeout),
      });
    } catch { throw failure('语雀文档创建结果待核对，请先检查语雀。', true); }
    try { body = await response.json(); } catch { throw failure('语雀文档创建未返回有效结果，请先检查语雀。', true); }
    if (!response.ok || body?.status >= 400) {
      const messageText = String(body?.message || body?.msg || body?.error || '').slice(0, 200);
      throw Object.assign(failure(response.status === 401 || response.status === 403 ? '语雀登录已失效，请重新登录后保存。' : `语雀创建文档失败${messageText ? '：' + messageText : '，请稍后重试。'}`, response.status >= 500), { needsLogin: response.status === 401 });
    }
    const data = body?.data || {};
    const id = String(data.id || '');
    const createdSlug = String(data.slug || slug);
    if (!/^[1-9]\d{0,19}$/.test(id)) throw failure('语雀未返回文档编号，请先检查知识库。', true);
    return { id, slug: createdSlug, url: `https://www.yuque.com/${repo}/${encodeURIComponent(createdSlug)}`, userId: current.userId };
  }
  async function upload(message) {
    const expected = userId(message.userId);
    if (!expected || !['image/png','image/jpeg','image/gif','image/webp'].includes(message.mime) || typeof message.base64 !== 'string' || !message.base64.length || message.base64.length > Math.ceil(MAX/3)*4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(message.base64)) throw failure('图片传输内容无效，请重新获取。');
    let bytes; try { bytes = Uint8Array.from(atob(message.base64), char => char.charCodeAt(0)); } catch { throw failure('图片传输内容无效，请重新获取。'); }
    if (!bytes.length || bytes.length > MAX) throw failure('图片超过本次传输上限，请重新获取。');
    const current = await mine();
    if (current.userId !== expected) throw Object.assign(failure('请在语雀登录个人令牌所属的同一账户，再返回拾句保存。'),{needsLogin:true});
    const token = csrf(), query = new URLSearchParams({attachable_type:'User',attachable_id:expected,type:'image',ctoken:token});
    const form = new FormData(); form.append('file',new Blob([bytes],{type:message.mime}), /^shiju-[\w-]+\.(png|jpg|gif|webp)$/.test(message.filename) ? message.filename : 'shiju-image.png');
    const retryable = new Set([408, 425, 429, 500, 502, 503, 504]);
    let response, body;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        response = await fetch('/api/upload/attach?'+query,{method:'POST',credentials:'same-origin',redirect:'error',cache:'no-store',headers:{'x-csrf-token':token},body:form,signal:AbortSignal.timeout(globalThis.__shijuImagePolicy.uploadTimeout)});
        if (response.ok || !retryable.has(response.status)) break;
      } catch {
        if (attempt === 2) throw failure('语雀图片上传连接中断，未创建正文，请检查语雀后重试。', true);
      }
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 700 * (attempt + 1)));
    }
    if (!response) throw failure('语雀图片上传未得到结果，未创建正文，请检查语雀后重试。', true);
    if (!response.ok) {
      let detail = '';
      try { const text = await response.text(); try { const parsed = JSON.parse(text); detail = String(parsed.message || parsed.msg || parsed.error || ''); } catch { detail = text.slice(0, 120); } } catch {}
      throw Object.assign(failure(response.status === 401 || response.status === 403 ? `语雀图片上传被拒绝${detail ? '：' + detail : '，请确认语雀登录状态与保存权限后重试。'}` : `语雀图片上传失败${detail ? '：' + detail : `（HTTP ${response.status}），未创建正文，可从记录继续。`}`,false),{needsLogin:response.status===401});
    }
    try { body = await response.json(); } catch { throw failure('语雀图片上传未返回有效结果，未创建正文，可从记录继续。', false); }
    if (body?.status >= 400 || body?.error || body?.code && body.code !== 0) { const raw = body?.message || body?.msg || body?.error?.message || body?.error || ''; const detail = typeof raw === 'string' ? raw.slice(0, 200) : ''; throw failure(`语雀图片上传失败${detail ? '：' + detail : `（状态 ${body?.status || body?.code || '未知'}）`}，未创建正文，可从记录继续。`,false); }
    let url; try { url = new URL(body?.data?.url); } catch { throw failure('语雀图片地址缺失，未创建正文，可从记录继续。',false); }
    if (url.protocol !== 'https:' || url.hostname !== 'cdn.nlark.com' || !url.pathname.startsWith('/yuque/') || url.username || url.password || url.port || url.href.length > 8000) throw failure('语雀返回的图片地址异常，未创建正文，可从记录继续。',false);
    return {url:url.href};
  }
  chrome.runtime.onMessage.addListener((message,sender,respond) => {
    if (sender.id !== chrome.runtime.id || !['YUQUE_SESSION_READ','YUQUE_REPOS','YUQUE_CREATE_DOC','YUQUE_IMAGE_UPLOAD'].includes(message?.type)) return;
    const work = message.type === 'YUQUE_SESSION_READ' ? mine() : message.type === 'YUQUE_REPOS' ? repos() : message.type === 'YUQUE_CREATE_DOC' ? createDoc(message) : upload(message);
    work.then(data=>respond({ok:true,data})).catch(error=>respond({ok:false,error:error.message,uncertain:Boolean(error.uncertain),needsLogin:Boolean(error.needsLogin)}));
    return true;
  });
})();
